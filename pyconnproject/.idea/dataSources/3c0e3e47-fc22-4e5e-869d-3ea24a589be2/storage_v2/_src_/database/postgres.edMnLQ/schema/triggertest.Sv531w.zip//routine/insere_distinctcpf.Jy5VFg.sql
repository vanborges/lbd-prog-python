create function insere_distinctcpf() returns trigger
    language plpgsql
as
$$
DECLARE
isdistinct INTEGER;
BEGIN
isdistinct := (SELECT count(*) from t_funcionario WHERE cpf = NEW.cpf);
IF isdistinct=0 THEN        
INSERT INTO t_funcionario
VALUES (NEW.pnome, NEW.cpf, NEW.sexo, NEW.salario, NEW.cpf_supervisor, NEW.dnr);
RAISE NOTICE 'Registro inserido com sucesso (%, %, %, %)',$1,$2,$3,$4;
RETURN NULL;
ELSE
RAISE EXCEPTION 'CPF inválido';
END IF;
END;
$$;

alter function insere_distinctcpf() owner to postgres;

