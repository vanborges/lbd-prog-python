create function "moveAcademicoTurmaToHistorico"(anoingresso integer) returns void
    language plpgsql
as
$$
DECLARE
  totalAcademicoAtivos SMALLINT; -- so podera mover os academico se todos estiverem excluidos.
  totalAcademicos INTEGER; -- total de academicos que tiveram seus registros movidos para o historico.
  totalRegistros INTEGER; -- total de registros a serem movidos.
BEGIN
  
	-- contando o número de academicos que se encontram ativos
    -- cuja ano de ingresso e igual ao passado como parametro.
    SELECT INTO totalAcademicoAtivos count(*)
    FROM academico
    WHERE "academicoAnoIngresso" = anoIngresso AND
          "academicoSituacao" = 'I';
     
    -- se existir algum academico com situção igual a I (ativo), abortar o processo.   
    IF totalAcademicoAtivos > 0 THEN
    	RAISE EXCEPTION 'Existem academicos que ingressaram em % cuja situação e diferente de E (excluido) [TOTAL:%] !',anoIngresso,totalAcademicoAtivos;
    END IF;      
    
    -- contabilizar o numero de academicos a serem transferidos.
    SELECT INTO totalAcademicos count(DISTINCT a."academicoId")
    FROM academico a JOIN "academicoTurma" t ON a."academicoId" = t."academicoId"
    WHERE a."academicoAnoIngresso" = anoIngresso AND
          a."academicoSituacao" = 'E';
          
	-- contabilizar o numero de registros na tabela academicoTurma a serem
    -- transferido para a tabela academicoTurmaHistorico.
    SELECT INTO totalRegistros count(*)
    FROM academico a JOIN "academicoTurma" t ON a."academicoId" = t."academicoId"
    WHERE a."academicoAnoIngresso" = anoIngresso AND
          a."academicoSituacao" = 'E';
    
    -- o atributo isHistoric indica que o "Historico" do academico já esta
    -- na tabela academicoTurmaHistorico      
    UPDATE academico SET "isHistoric" = true 
	WHERE "academicoAnoIngresso" = anoIngresso AND "isHistoric" IS FALSE;

	-- copia todos os registros da tabela academicoTurma dos academicos que
    -- entraram no ano de referencia para a tabela academicoTurmaHistorico.
    INSERT INTO "academicoTurmaHistorico"
	SELECT t.*
	FROM academico a JOIN  "academicoTurma" t ON a."academicoId" = t."academicoId"
	where a."academicoAnoIngresso" = anoIngresso;

	-- excluindo os registros da tabela academicoTurma dos academicos que 
    -- entraram no ano de referencia.
	DELETE FROM "academicoTurma" 
	WHERE "academicoTurma"."academicoId" IN 
	(SELECT "academicoId" FROM academico WHERE "academicoAnoIngresso" = anoIngresso);
            
    RAISE NOTICE 'Total de academicos : %, Total de Registros da academicoTurma: %',totalAcademicos,totalRegistros;    

END;
$$;

comment on function "moveAcademicoTurmaToHistorico"(integer) is 'A função move todos os registros da tabela academicoTurma para a tabela
academicoTurmaHistorico dos academico que tiverem ano de ingresso igual ao passado
para a função. Esta ação somente será realizada se todos
os academicos tiverem a situação definida na coluna academicoSituacao = E  ';

alter function "moveAcademicoTurmaToHistorico"(integer) owner to postgres;

