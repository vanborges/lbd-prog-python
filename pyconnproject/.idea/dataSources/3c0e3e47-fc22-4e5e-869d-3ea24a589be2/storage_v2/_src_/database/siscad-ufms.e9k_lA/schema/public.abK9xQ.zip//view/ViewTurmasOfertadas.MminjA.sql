create view "ViewTurmasOfertadas"("ViewTurmasOfertadasCentroId", "ViewTurmasOfertadasCursoId",
                                  "ViewTurmasOfertadasCursoCodigo", "ViewTurmasOfertadasCursoSequencia",
                                  "ViewTurmasOfertadasCursoNome", "ViewTurmasOfertadasGradeId",
                                  "ViewTurmasOfertadasDisciplinaId", "ViewTurmasOfertadasDisciplinaCodigo",
                                  "ViewTurmasOfertadasDisciplinaNome", "ViewTurmasOfertadasDisciplinaCarga",
                                  "ViewTurmasOfertadasId", "ViewTurmasOfertadasOfertaAno",
                                  "ViewTurmasOfertadasOfertaSemestre", "ViewTurmasOfertadasTurmaId",
                                  "ViewTurmasOfertadasTurmaTipo", "ViewTurmasOfertadasTurmaNome",
                                  "ViewTurmasOfertadasTurmaSerie", "ViewTurmasOfertadasTurmaBloqueio",
                                  "ViewTurmasOfertadasTurmaIsFather") as
SELECT c."centroId"         AS "ViewTurmasOfertadasCentroId",
       c."cursoId"          AS "ViewTurmasOfertadasCursoId",
       c."cursoCodigo"      AS "ViewTurmasOfertadasCursoCodigo",
       c."cursoSequencia"   AS "ViewTurmasOfertadasCursoSequencia",
       c."cursoNome"        AS "ViewTurmasOfertadasCursoNome",
       g."gradeId"          AS "ViewTurmasOfertadasGradeId",
       d."disciplinaId"     AS "ViewTurmasOfertadasDisciplinaId",
       d."disciplinaCodigo" AS "ViewTurmasOfertadasDisciplinaCodigo",
       d."disciplinaNome"   AS "ViewTurmasOfertadasDisciplinaNome",
       d."disciplinaCarga"  AS "ViewTurmasOfertadasDisciplinaCarga",
       o."ofertaId"         AS "ViewTurmasOfertadasId",
       o."ofertaAno"        AS "ViewTurmasOfertadasOfertaAno",
       o."ofertaSemestre"   AS "ViewTurmasOfertadasOfertaSemestre",
       t."turmaId"          AS "ViewTurmasOfertadasTurmaId",
       t."turmaTipo"        AS "ViewTurmasOfertadasTurmaTipo",
       t."turmaNome"        AS "ViewTurmasOfertadasTurmaNome",
       t."turmaSerie"       AS "ViewTurmasOfertadasTurmaSerie",
       t."turmaBloqueio"    AS "ViewTurmasOfertadasTurmaBloqueio",
       t."turmaIsFather"    AS "ViewTurmasOfertadasTurmaIsFather"
FROM ((((curso c
    JOIN grade g ON ((c."cursoId" = g."cursoId")))
    JOIN disciplina d ON ((g."disciplinaId" = d."disciplinaId")))
    JOIN oferta o ON ((g."gradeId" = o."gradeId")))
         JOIN turma t ON ((o."ofertaId" = t."ofertaId")))
ORDER BY c."cursoCodigo", c."cursoSequencia", (to_ascii((c."cursoNome")::text)), (to_ascii((d."disciplinaNome")::text)),
         t."turmaNome";

alter table "ViewTurmasOfertadas"
    owner to postgres;

