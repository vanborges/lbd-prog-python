create function alterar_grupo() returns trigger
    language plpgsql
as
$$
BEGIN

if old."usrCreateDate" = old."usrUpdateDate" then
update "usrSystem"
  set "systemId" = 4
  where "usrId" = old."usrId"
  and "systemId" = 3;

end if;

    RETURN NEW;
END;
$$;

alter function alterar_grupo() owner to postgres;

