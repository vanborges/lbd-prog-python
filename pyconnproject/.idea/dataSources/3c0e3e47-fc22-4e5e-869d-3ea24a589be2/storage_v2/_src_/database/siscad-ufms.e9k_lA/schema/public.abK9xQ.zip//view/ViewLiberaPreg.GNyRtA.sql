create view "ViewLiberaPreg"("ViewLiberaPregsequencia", "ViewLiberaPregturma", "ViewLiberaPregdisciplinaNome",
                             "ViewLiberaPregId", "ViewLiberaPregqtde") as
SELECT b."academicoTurmaSeqBloqueio" AS "ViewLiberaPregsequencia",
       t."DP_TURMAF"                 AS "ViewLiberaPregturma",
       d."disciplinaNome"            AS "ViewLiberaPregdisciplinaNome",
       b."turmaId"                   AS "ViewLiberaPregId",
       count(*)                      AS "ViewLiberaPregqtde"
FROM ((("academicoTurma" b
    JOIN turma t ON ((t."turmaId" = b."turmaId")))
    JOIN oferta o ON ((o."ofertaId" = t."ofertaId")))
         JOIN disciplina d ON ((d."disciplinaId" = o."_disciplinaId")))
WHERE (b."academicoTurmaBloqueioMF" = 1)
GROUP BY b."academicoTurmaSeqBloqueio", t."DP_TURMAF", d."disciplinaNome", b."turmaId";

alter table "ViewLiberaPreg"
    owner to postgres;

