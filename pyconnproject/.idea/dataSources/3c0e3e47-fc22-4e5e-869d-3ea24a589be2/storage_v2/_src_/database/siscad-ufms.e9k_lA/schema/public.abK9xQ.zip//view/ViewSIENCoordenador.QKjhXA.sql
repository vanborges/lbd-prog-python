create view "ViewSIENCoordenador"(id, curso_codigo, docente_id, curso_id, nome) as
SELECT cu."cursoId"     AS id,
       cu."cursoCodigo" AS curso_codigo,
       co."docenteId"   AS docente_id,
       cu."cursoId"     AS curso_id,
       d."docenteNome"  AS nome
FROM ((curso cu
    JOIN coordenador co ON ((cu."cursoId" = co."cursoId")))
         JOIN docente d ON ((d."docenteId" = co."docenteId")));

alter table "ViewSIENCoordenador"
    owner to postgres;

