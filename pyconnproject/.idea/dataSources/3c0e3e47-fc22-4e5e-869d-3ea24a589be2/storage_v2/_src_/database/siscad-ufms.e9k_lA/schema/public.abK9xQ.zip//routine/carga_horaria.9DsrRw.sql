create function carga_horaria("turmaId" integer, "disciplinaId" integer, "cursoId" integer) returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE
 turmaId ALIAS FOR $1;
 disciplinaId ALIAS FOR $2;
 cursoId  ALIAS FOR $3;
 Carga INTEGER;
 Carga2 INTEGER;
 TipoChLimitada CHAR(1);
BEGIN

     IF(turmaId is not null)THEN
         select into TipoChLimitada e."estruturaCargaHorariaLimitada"
         from estrutura e
         where e."estruturaId" in (select distinct estrutura."estruturaId"
                           from "cursoTurma" ct join oferta o on(ct."ofertaId"=o."ofertaId")
                                join grade g on (o."gradeId" = g."gradeId")
                                join estrutura on (g."estruturaId" = estrutura."estruturaId")                                                           
                           where ct."turmaId" = turmaId);

        if TipoChLimitada='S' then
        /* foi considerado que se a carga horaria for limitada, contabilizar
           a carga horaria cadastrada para o docente na docenteTurma */

        	/* select INTO Carga cast( sum(d."docenteTurmaChMinistrada") as integer)
			from "docenteTurma" d
			where d."turmaId" = turmaId or
            		d."turmaId" in (
						select t."turmaPai"
						from turma t
						where t."turmaId" = turmaId);
                           RAISE NOTICE 'PASSO 4'; */ 
                           
           /* se a carga horária for limitada contabilizar apenas (módulo do curso * 2)*/
		   select INTO Carga (c."cursoModulo"*2)
           from turma t 
                join oferta o  on  t."ofertaId" = o."ofertaId"
                join grade g on g."gradeId"=o."gradeId"
                join curso c on g."cursoId"=c."cursoId"
		        where  t."turmaId" = turmaId;
                RAISE NOTICE 'PASSO 4';
                
         else         
             select into Carga "ViewDiariodisciplinaCarga" as soma
             froM "ViewDiario"
             WHERE "ViewDiario"."ViewDiarioId" = turmaId;
         end if;

         select into Carga2 "ViewDiariodisciplinaCarga" as soma
         froM "ViewDiario"
         WHERE "ViewDiario"."ViewDiarioId" =turmaId;

     ELSE /* Reavaliar este ELSE - principalmente no que ser refere pegar a sequenica máxima do curso. */

        -- Fiz uma adaptação mas não esta correto ainda. (Márcio R. Silva)
        select INTO TipoChLimitada e."estruturaCargaHorariaLimitada"
		from grade g join estrutura e on e."estruturaId" = g."estruturaId"
		join curso c on g."cursoId" = c."cursoId"
		where  g."disciplinaId" = disciplinaId and 
		c."cursoCodigo" = cast( cursoId as "text")
		order by c."cursoSequencia" desc;
                
         /*
         select INTO TipoChLimitada e."estruturaCargaHorariaLimitada"
       	 from disciplina d join grade g on d."disciplinaId" = g."disciplinaId"
  	     join estrutura e on e."estruturaId" = g."estruturaId"
         join curso c on g."cursoId" = c."cursoId"
	     where 	c."cursoId"= 
         (
           select max(c."cursoSequencia")
           from curso c
           where c."cursoCodigo" = cursoId
          ) and g."gradeSituacao" = '1'	;
          */

          if(TipoChLimitada='S')then
          -- Fiz uma adaptação mas não esta correto ainda. (Márcio R. Silva)
             select INTO Carga (c."cursoModulo")*2
			 from curso c
			 where c."cursoCodigo"= cast ( cursoId as "text")
			 ORDER BY c."cursoSequencia" desc;

             /*
             select INTO Carga (c."cursoModulo")*2
             from curso c
             where c."cursoId"= cursoId and c."cursoSequencia"=
             (
               select max(c2."cursoSequencia")
               from curso c2
               where c2."cursoId"= cursoId
             );
             */
             
           else
              select INTO Carga d."disciplinaCarga"
              from disciplina d
              where d."disciplinaId"= disciplinaId;
           end if;
           select INTO Carga2 d."disciplinaCarga"
           from disciplina d
           where d."disciplinaId"= disciplinaId;
     END IF;
/*
     if(Carga2 < Carga )then
               Carga := Carga2;
     end if;
*/
     return Carga;
END;
$$;

alter function carga_horaria(integer, integer, integer) owner to postgres;

