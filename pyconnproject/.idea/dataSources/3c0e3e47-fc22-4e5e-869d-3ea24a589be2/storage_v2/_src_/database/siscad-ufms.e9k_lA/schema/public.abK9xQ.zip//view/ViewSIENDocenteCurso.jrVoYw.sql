create view "ViewSIENDocenteCurso"(docente_id, "docenteMatricula", "docenteDigitoVerificador", "docenteUfms",
                                   docente_nome, "docenteVinculo", "docenteSituacaoOcor", "docenteSituacao",
                                   "docenteGrupoSituacao", "docenteTipoSituacao", "docenteSexo", "docenteOcorTitulacao",
                                   "docenteClasse", "docenteNivel", "docenteArea", "docenteTitulacao",
                                   "docenteRegimeTrabalho", "docenteOcorFuncao", "docenteOrigemLotacao",
                                   "docenteFuncaoLotacao", "docenteAtividade", "docenteTipoFuncao",
                                   "docenteNivelFuncao", "docenteDataAdimissao", "docenteAnoDtBase", "docenteMesDtBase",
                                   "docenteAno", "docenteDepIngresso", "docenteTutor", "docenteOcorDepartamento",
                                   "docenteDepartamento", "docenteObs", "docenteParteNome", "docenteCreateDate",
                                   "vinculoId", "docenteCpf", "titulacaoId", curso_codigo) as
SELECT DISTINCT doc."docenteId"   AS docente_id,
                doc."docenteMatricula",
                doc."docenteDigitoVerificador",
                doc."docenteUfms",
                doc."docenteNome" AS docente_nome,
                doc."docenteVinculo",
                doc."docenteSituacaoOcor",
                doc."docenteSituacao",
                doc."docenteGrupoSituacao",
                doc."docenteTipoSituacao",
                doc."docenteSexo",
                doc."docenteOcorTitulacao",
                doc."docenteClasse",
                doc."docenteNivel",
                doc."docenteArea",
                doc."docenteTitulacao",
                doc."docenteRegimeTrabalho",
                doc."docenteOcorFuncao",
                doc."docenteOrigemLotacao",
                doc."docenteFuncaoLotacao",
                doc."docenteAtividade",
                doc."docenteTipoFuncao",
                doc."docenteNivelFuncao",
                doc."docenteDataAdimissao",
                doc."docenteAnoDtBase",
                doc."docenteMesDtBase",
                doc."docenteAno",
                doc."docenteDepIngresso",
                doc."docenteTutor",
                doc."docenteOcorDepartamento",
                doc."docenteDepartamento",
                doc."docenteObs",
                doc."docenteParteNome",
                doc."docenteCreateDate",
                doc."vinculoId",
                doc."docenteCpf",
                doc."titulacaoId",
                ct."cursoCodigo"  AS curso_codigo
FROM (((docente doc
    JOIN "docenteTurma" dt ON ((doc."docenteId" = dt."docenteId")))
    JOIN "cursoTurma" ct ON ((ct."turmaId" = dt."turmaId")))
         JOIN turma t ON ((t."turmaId" = dt."turmaId")))
WHERE (((t."turmaAno")::double precision = date_part('year'::text, now())) AND
       (doc."docenteSituacao" <> ALL (ARRAY ['02'::bpchar, '05'::bpchar])) AND (doc."docenteId" <> 1))
ORDER BY doc."docenteNome", doc."docenteId", doc."docenteMatricula", doc."docenteDigitoVerificador", doc."docenteUfms",
         doc."docenteVinculo", doc."docenteSituacaoOcor", doc."docenteSituacao", doc."docenteGrupoSituacao",
         doc."docenteTipoSituacao", doc."docenteSexo", doc."docenteOcorTitulacao", doc."docenteClasse",
         doc."docenteNivel", doc."docenteArea", doc."docenteTitulacao", doc."docenteRegimeTrabalho",
         doc."docenteOcorFuncao", doc."docenteOrigemLotacao", doc."docenteFuncaoLotacao", doc."docenteAtividade",
         doc."docenteTipoFuncao", doc."docenteNivelFuncao", doc."docenteDataAdimissao", doc."docenteAnoDtBase",
         doc."docenteMesDtBase", doc."docenteAno", doc."docenteDepIngresso", doc."docenteTutor",
         doc."docenteOcorDepartamento", doc."docenteDepartamento", doc."docenteObs", doc."docenteParteNome",
         doc."docenteCreateDate", doc."vinculoId", doc."docenteCpf", doc."titulacaoId", ct."cursoCodigo";

alter table "ViewSIENDocenteCurso"
    owner to postgres;

