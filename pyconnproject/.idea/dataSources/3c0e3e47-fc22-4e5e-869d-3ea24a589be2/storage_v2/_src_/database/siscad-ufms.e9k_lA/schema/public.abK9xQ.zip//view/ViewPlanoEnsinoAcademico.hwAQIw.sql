create view "ViewPlanoEnsinoAcademico"("ViewPlanoEnsinoAcademicoId", "ViewPlanoEnsinoAcademicoRGA",
                                       "ViewPlanoEnsinoAcademicodisciplinaCodigo",
                                       "ViewPlanoEnsinoAcademicodisciplinaNome",
                                       "ViewPlanoEnsinoAcademicodisciplinaCarga", "ViewPlanoEnsinoAcademicoturmaTipo",
                                       "ViewPlanoEnsinoAcademicoturmaNome", "foreignId",
                                       "ViewPlanoEnsinoAcademicoofertaId", "ViewPlanoEnsinoAcademicoAno",
                                       "ViewPlanoEnsinoAcademicoSemestre", "ViewPlanoEnsinoAcademicoofertaDuracao",
                                       "ViewPlanoEnsinoAcademicocursoId", "ViewPlanoEnsinoAcademicocursoCodigo",
                                       "ViewPlanoEnsinoAcademicocursoSequencia", "ViewPlanoEnsinoAcademicocursoNome",
                                       "ViewPlanoEnsinoAcademicodepartamentoSigla",
                                       "ViewPlanoEnsinoAcademicodepartamentoNome", "ViewPlanoEnsinoAcademicocentroId",
                                       "ViewPlanoEnsinoAcademicocentroSigla", "ViewPlanoEnsinoAcademicocentroNome",
                                       "ViewPlanoEnsinoAcademicoplanoEnsinoId", "ViewPlanoEnsinoAcademicousrId") as
SELECT t."turmaId"             AS "ViewPlanoEnsinoAcademicoId",
       act."RGA"               AS "ViewPlanoEnsinoAcademicoRGA",
       d."disciplinaCodigo"    AS "ViewPlanoEnsinoAcademicodisciplinaCodigo",
       d."disciplinaNome"      AS "ViewPlanoEnsinoAcademicodisciplinaNome",
       d."disciplinaCarga"     AS "ViewPlanoEnsinoAcademicodisciplinaCarga",
       t."turmaTipo"           AS "ViewPlanoEnsinoAcademicoturmaTipo",
       t."turmaNome"           AS "ViewPlanoEnsinoAcademicoturmaNome",
       act."academicoId"       AS "foreignId",
       o."ofertaId"            AS "ViewPlanoEnsinoAcademicoofertaId",
       o."ofertaAno"           AS "ViewPlanoEnsinoAcademicoAno",
       o."ofertaSemestre"      AS "ViewPlanoEnsinoAcademicoSemestre",
       o."ofertaDuracao"       AS "ViewPlanoEnsinoAcademicoofertaDuracao",
       cur."cursoId"           AS "ViewPlanoEnsinoAcademicocursoId",
       cur."cursoCodigo"       AS "ViewPlanoEnsinoAcademicocursoCodigo",
       cur."cursoSequencia"    AS "ViewPlanoEnsinoAcademicocursoSequencia",
       cur."cursoNome"         AS "ViewPlanoEnsinoAcademicocursoNome",
       dep."departamentoSigla" AS "ViewPlanoEnsinoAcademicodepartamentoSigla",
       dep."departamentoNome"  AS "ViewPlanoEnsinoAcademicodepartamentoNome",
       cent."centroId"         AS "ViewPlanoEnsinoAcademicocentroId",
       cent."centroSigla"      AS "ViewPlanoEnsinoAcademicocentroSigla",
       cent."centroNome"       AS "ViewPlanoEnsinoAcademicocentroNome",
       t."planoEnsinoId"       AS "ViewPlanoEnsinoAcademicoplanoEnsinoId",
       p."usrId"               AS "ViewPlanoEnsinoAcademicousrId"
FROM (((((((((turma t
    JOIN "academicoTurma" act ON ((act."turmaId" = t."turmaId")))
    JOIN academico acad ON ((acad."academicoId" = act."academicoId")))
    LEFT JOIN "planoEnsino" p ON ((t."planoEnsinoId" = p."planoEnsinoId")))
    JOIN oferta o ON ((t."ofertaId" = o."ofertaId")))
    JOIN grade g ON ((o."gradeId" = g."gradeId")))
    JOIN (SELECT c."centroId",
                 c."cursoId",
                 c."cursoCodigo",
                 c."cursoSequencia",
                 c."cursoNome",
                 ct."turmaId"
          FROM (curso c
                   JOIN "cursoTurma" ct
                        ON (((ct."cursoCodigo")::bpchar = c."cursoCodigo")))) cur ON (((cur."turmaId" = t."turmaId") AND (cur."cursoId" = acad."cursoId"))))
    JOIN disciplina d ON ((g."disciplinaId" = d."disciplinaId")))
    JOIN departamento dep ON ((dep."departamentoId" = d."departamentoId")))
         JOIN centro cent ON ((cent."centroId" = cur."centroId")))
WHERE (t."turmaTipo" <> 't'::bpchar);

alter table "ViewPlanoEnsinoAcademico"
    owner to postgres;

