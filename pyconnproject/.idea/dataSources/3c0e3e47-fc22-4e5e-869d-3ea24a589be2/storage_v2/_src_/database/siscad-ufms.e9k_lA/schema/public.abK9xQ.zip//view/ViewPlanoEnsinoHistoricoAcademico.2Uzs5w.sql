create view "ViewPlanoEnsinoHistoricoAcademico"("ViewPlanoEnsinoHistoricoAcademicoId",
                                                "ViewPlanoEnsinoHistoricoAcademicoRGA",
                                                "ViewPlanoEnsinoHistoricoAcademicodisciplinaCodigo",
                                                "ViewPlanoEnsinoHistoricoAcademicodisciplinaNome",
                                                "ViewPlanoEnsinoHistoricoAcademicodisciplinaCarga", "foreignId",
                                                "ViewPlanoEnsinoHistoricoAcademicoAno",
                                                "ViewPlanoEnsinoHistoricoAcademicoSemestre",
                                                "ViewPlanoEnsinoHistoricoAcademicocursoId",
                                                "ViewPlanoEnsinoHistoricoAcademicocursoCodigo",
                                                "ViewPlanoEnsinoHistoricoAcademicocursoNome",
                                                "ViewPlanoEnsinoHistoricoAcademicodepartamentoSigla",
                                                "ViewPlanoEnsinoHistoricoAcademicodepartamentoNome",
                                                "ViewPlanoEnsinoHistoricoAcademicocentroId",
                                                "ViewPlanoEnsinoHistoricoAcademicocentroSigla",
                                                "ViewPlanoEnsinoHistoricoAcademicocentroNome",
                                                "ViewPlanoEnsinoHistoricoAcademicoplanoEnsinoId",
                                                "ViewPlanoEnsinoHistoricoAcademicousrId",
                                                "ViewPlanoEnsinoHistoricoAcademicoturmaTipo",
                                                "ViewPlanoEnsinoHistoricoAcademicoturmaNome") as
    SELECT 0                          AS "ViewPlanoEnsinoHistoricoAcademicoId",
           act."RGA"                  AS "ViewPlanoEnsinoHistoricoAcademicoRGA",
           d."disciplinaCodigo"       AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaCodigo",
           d."disciplinaNome"         AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaNome",
           d."disciplinaCarga"        AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaCarga",
           act."academicoId"          AS "foreignId",
           act."ANO"                  AS "ViewPlanoEnsinoHistoricoAcademicoAno",
           act."SEM"                  AS "ViewPlanoEnsinoHistoricoAcademicoSemestre",
           c."cursoId"                AS "ViewPlanoEnsinoHistoricoAcademicocursoId",
           c."cursoCodigo"            AS "ViewPlanoEnsinoHistoricoAcademicocursoCodigo",
           c."cursoNome"              AS "ViewPlanoEnsinoHistoricoAcademicocursoNome",
           dep."departamentoSigla"    AS "ViewPlanoEnsinoHistoricoAcademicodepartamentoSigla",
           dep."departamentoNome"     AS "ViewPlanoEnsinoHistoricoAcademicodepartamentoNome",
           cent."centroId"            AS "ViewPlanoEnsinoHistoricoAcademicocentroId",
           cent."centroSigla"         AS "ViewPlanoEnsinoHistoricoAcademicocentroSigla",
           cent."centroNome"          AS "ViewPlanoEnsinoHistoricoAcademicocentroNome",
           p."planoEnsinoHistoricoId" AS "ViewPlanoEnsinoHistoricoAcademicoplanoEnsinoId",
           p."usrId"                  AS "ViewPlanoEnsinoHistoricoAcademicousrId",
           0                          AS "ViewPlanoEnsinoHistoricoAcademicoturmaTipo",
           0                          AS "ViewPlanoEnsinoHistoricoAcademicoturmaNome"
    FROM ((((((academico a
        JOIN "academicoTurma" act ON ((act."academicoId" = a."academicoId")))
        JOIN curso c ON ((a."cursoId" = c."cursoId")))
        JOIN disciplina d ON ((d."disciplinaId" = act."disciplinaId")))
        JOIN departamento dep ON ((dep."departamentoId" = d."departamentoId")))
        JOIN centro cent ON ((dep."centroId" = cent."centroId")))
             LEFT JOIN "planoEnsinoHistorico" p
                       ON (((p."disciplinaId" = d."disciplinaId") AND ((p."CURSO")::bpchar = c."cursoCodigo"))))
    WHERE (((act."turmaId" IS NULL) OR (act."turmaId" = 0)) AND (act."academicoTurmaPregSituacao" = 'AP'::bpchar))
    UNION
    SELECT 0                          AS "ViewPlanoEnsinoHistoricoAcademicoId",
           act."RGA"                  AS "ViewPlanoEnsinoHistoricoAcademicoRGA",
           d."disciplinaCodigo"       AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaCodigo",
           d."disciplinaNome"         AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaNome",
           d."disciplinaCarga"        AS "ViewPlanoEnsinoHistoricoAcademicodisciplinaCarga",
           act."academicoId"          AS "foreignId",
           act."ANO"                  AS "ViewPlanoEnsinoHistoricoAcademicoAno",
           act."SEM"                  AS "ViewPlanoEnsinoHistoricoAcademicoSemestre",
           c."cursoId"                AS "ViewPlanoEnsinoHistoricoAcademicocursoId",
           c."cursoCodigo"            AS "ViewPlanoEnsinoHistoricoAcademicocursoCodigo",
           c."cursoNome"              AS "ViewPlanoEnsinoHistoricoAcademicocursoNome",
           dep."departamentoSigla"    AS "ViewPlanoEnsinoHistoricoAcademicodepartamentoSigla",
           dep."departamentoNome"     AS "ViewPlanoEnsinoHistoricoAcademicodepartamentoNome",
           cent."centroId"            AS "ViewPlanoEnsinoHistoricoAcademicocentroId",
           cent."centroSigla"         AS "ViewPlanoEnsinoHistoricoAcademicocentroSigla",
           cent."centroNome"          AS "ViewPlanoEnsinoHistoricoAcademicocentroNome",
           p."planoEnsinoHistoricoId" AS "ViewPlanoEnsinoHistoricoAcademicoplanoEnsinoId",
           p."usrId"                  AS "ViewPlanoEnsinoHistoricoAcademicousrId",
           0                          AS "ViewPlanoEnsinoHistoricoAcademicoturmaTipo",
           0                          AS "ViewPlanoEnsinoHistoricoAcademicoturmaNome"
    FROM ((((((academico a
        JOIN "academicoTurmaHistorico" act ON ((act."academicoId" = a."academicoId")))
        JOIN curso c ON ((a."cursoId" = c."cursoId")))
        JOIN disciplina d ON ((d."disciplinaId" = act."disciplinaId")))
        JOIN departamento dep ON ((dep."departamentoId" = d."departamentoId")))
        JOIN centro cent ON ((dep."centroId" = cent."centroId")))
             LEFT JOIN "planoEnsinoHistorico" p
                       ON (((p."disciplinaId" = d."disciplinaId") AND ((p."CURSO")::bpchar = c."cursoCodigo"))))
    WHERE (((act."turmaId" IS NULL) OR (act."turmaId" = 0)) AND (act."academicoTurmaPregSituacao" = 'AP'::bpchar));

alter table "ViewPlanoEnsinoHistoricoAcademico"
    owner to postgres;

