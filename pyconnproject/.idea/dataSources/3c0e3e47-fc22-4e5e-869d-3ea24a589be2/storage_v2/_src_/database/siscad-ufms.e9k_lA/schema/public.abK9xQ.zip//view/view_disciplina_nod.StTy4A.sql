create view view_disciplina_nod("disciplinaNome") as
SELECT DISTINCT d."disciplinaNome"
FROM disciplina d
WHERE ((d."disciplinaSituacao" = 'I'::bpchar) AND
       (d."departamentoId" = ANY (ARRAY ['0108'::bpchar, '1101'::bpchar, '1102'::bpchar, '1103'::bpchar])))
ORDER BY d."disciplinaNome";

alter table view_disciplina_nod
    owner to postgres;

