create view "ViewDiario"("ViewDiarioId", "ViewDiariodisciplinaCodigo", "ViewDiariodisciplinaNome",
                         "ViewDiariodisciplinaCarga", "ViewDiarioturmaNome", "ViewDiarioturmaBloqueio", "foreignId",
                         "ViewDiarioofertaDuracao", "ViewDiarioofertaId", "ViewDiarioAno", "ViewDiarioofertaSemestre",
                         "ViewDiariocursoId", "ViewDiariocursoSequencia", "ViewDiariocursoCodigo",
                         "ViewDiariocursoNome", "ViewDiariodepartamentoSigla", "ViewDiariodepartamentoNome",
                         "ViewDiariocentroSigla", "ViewDiariocentroNome", "ViewDiariomodalidadeId") as
    SELECT turma."turmaId"                                          AS "ViewDiarioId",
           disciplina."disciplinaCodigo"                            AS "ViewDiariodisciplinaCodigo",
           disciplina."disciplinaNome"                              AS "ViewDiariodisciplinaNome",
           disciplina."disciplinaCarga"                             AS "ViewDiariodisciplinaCarga",
           ((turma."turmaTipo")::text || (turma."turmaNome")::text) AS "ViewDiarioturmaNome",
           turma."turmaBloqueio"                                    AS "ViewDiarioturmaBloqueio",
           "docenteTurma"."docenteId"                               AS "foreignId",
           oferta."ofertaDuracao"                                   AS "ViewDiarioofertaDuracao",
           oferta."ofertaId"                                        AS "ViewDiarioofertaId",
           oferta."ofertaAno"                                       AS "ViewDiarioAno",
           oferta."ofertaSemestre"                                  AS "ViewDiarioofertaSemestre",
           curso."cursoId"                                          AS "ViewDiariocursoId",
           curso."cursoSequencia"                                   AS "ViewDiariocursoSequencia",
           curso."cursoCodigo"                                      AS "ViewDiariocursoCodigo",
           curso."cursoNome"                                        AS "ViewDiariocursoNome",
           departamento."departamentoSigla"                         AS "ViewDiariodepartamentoSigla",
           departamento."departamentoNome"                          AS "ViewDiariodepartamentoNome",
           centro."centroSigla"                                     AS "ViewDiariocentroSigla",
           centro."centroNome"                                      AS "ViewDiariocentroNome",
           curso."modalidadeId"                                     AS "ViewDiariomodalidadeId"
    FROM (((((((("docenteTurma"
        JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaPai")))
        JOIN (SELECT "cursoTurma"."turmaId",
                     "cursoTurma"."ofertaId"
              FROM "cursoTurma" "cursoTurma"
              GROUP BY "cursoTurma"."turmaId", "cursoTurma"."ofertaId") "ViewCursoTurma" ON (("ViewCursoTurma"."turmaId" = turma."turmaId")))
        JOIN oferta ON (("ViewCursoTurma"."ofertaId" = oferta."ofertaId")))
        JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
        JOIN curso ON ((grade."cursoId" = curso."cursoId")))
        JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
        JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
             JOIN centro ON ((departamento."centroId" = centro."centroId")))
    WHERE (turma."turmaIsFather" IS FALSE)
    UNION
    SELECT turma."turmaId"                                          AS "ViewDiarioId",
           disciplina."disciplinaCodigo"                            AS "ViewDiariodisciplinaCodigo",
           disciplina."disciplinaNome"                              AS "ViewDiariodisciplinaNome",
           disciplina."disciplinaCarga"                             AS "ViewDiariodisciplinaCarga",
           ((turma."turmaTipo")::text || (turma."turmaNome")::text) AS "ViewDiarioturmaNome",
           turma."turmaBloqueio"                                    AS "ViewDiarioturmaBloqueio",
           "docenteTurma"."docenteId"                               AS "foreignId",
           oferta."ofertaDuracao"                                   AS "ViewDiarioofertaDuracao",
           oferta."ofertaId"                                        AS "ViewDiarioofertaId",
           oferta."ofertaAno"                                       AS "ViewDiarioAno",
           oferta."ofertaSemestre"                                  AS "ViewDiarioofertaSemestre",
           curso."cursoId"                                          AS "ViewDiariocursoId",
           curso."cursoSequencia"                                   AS "ViewDiariocursoSequencia",
           curso."cursoCodigo"                                      AS "ViewDiariocursoCodigo",
           curso."cursoNome"                                        AS "ViewDiariocursoNome",
           departamento."departamentoSigla"                         AS "ViewDiariodepartamentoSigla",
           departamento."departamentoNome"                          AS "ViewDiariodepartamentoNome",
           centro."centroSigla"                                     AS "ViewDiariocentroSigla",
           centro."centroNome"                                      AS "ViewDiariocentroNome",
           curso."modalidadeId"                                     AS "ViewDiariomodalidadeId"
    FROM (((((((("docenteTurma"
        JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaId")))
        JOIN (SELECT "cursoTurma"."turmaId",
                     "cursoTurma"."ofertaId"
              FROM "cursoTurma" "cursoTurma"
              GROUP BY "cursoTurma"."turmaId", "cursoTurma"."ofertaId") "ViewCursoTurma" ON (("ViewCursoTurma"."turmaId" = turma."turmaId")))
        JOIN oferta ON (("ViewCursoTurma"."ofertaId" = oferta."ofertaId")))
        JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
        JOIN curso ON ((grade."cursoId" = curso."cursoId")))
        JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
        JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
             JOIN centro ON ((departamento."centroId" = centro."centroId")))
    WHERE (turma."turmaIsFather" IS FALSE);

alter table "ViewDiario"
    owner to postgres;

