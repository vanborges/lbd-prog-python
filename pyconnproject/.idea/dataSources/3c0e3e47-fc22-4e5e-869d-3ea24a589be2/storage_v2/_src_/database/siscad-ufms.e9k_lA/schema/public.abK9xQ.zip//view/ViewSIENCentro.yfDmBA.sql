create view "ViewSIENCentro"(cidade_id, sigla, nome, local, rodape1, rodape2, created, id) as
SELECT centro."cidadeId"         AS cidade_id,
       centro."centroSigla"      AS sigla,
       centro."centroNome"       AS nome,
       centro."centroLocal"      AS local,
       centro."centroRodape1"    AS rodape1,
       centro."centroRodape2"    AS rodape2,
       centro."centroCreateDate" AS created,
       centro."centroId"         AS id
FROM centro
WHERE ((centro."cidadeId" <> '00'::bpchar) AND (centro."centroId" <> ALL (ARRAY [2, 99])));

alter table "ViewSIENCentro"
    owner to postgres;

