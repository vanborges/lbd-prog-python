create function busca_discentes_bolsas(cpf character varying) returns SETOF record
    language plpgsql
as
$$
BEGIN

RETURN QUERY
    SELECT
    a."academicoId",
    btrim(tp."tipoSituacaoTipo"::text, ' '::text)::character varying,
    btrim(tp."tipoSituacaoSigla"::text, ' '::text)::character varying,
    tp."tipoSituacaoNome" ,
    a."academicoNome",
    a."academicoEmail",
    a."academicoSexo",
    a."academicoCpf",
    a."academicoRga",
    a."academicoDtNasc",
    a."paisSiglaNacionalidade",
    esta."descricao",
    cid."descricao",
    cur."cursoId",
    cur."cursoCodigo",
    cur."cursoNome",
    tur."turnoDescricao",
    cen."centroId",
    cen."centroSigla",
    cen."centroNome",
    o."ocorrenciaAno",
    o."ocorrenciaSemestre",
    o."ocorrenciaCreateDate",
    'SISCAD'::character varying as origem_integracao
    FROM academico a
    	JOIN ocorrencia o ON a."academicoId" = o."academicoId"
    	JOIN curso cur ON cur."cursoId" = a."cursoId"
	JOIN turno tur ON tur."turnoId" = cur."turnoId"
	JOIN "tipoSituacao" tp ON o."tipoSituacaoId" = tp."tipoSituacaoId"
    	LEFT JOIN centro cen ON cen."centroId" = a."centroId"
    	LEFT JOIN pessoas.cidades cid ON cid."cidade_id" = a."academicoNatCidadeId"
        LEFT JOIN pessoas.estados esta ON esta.estado_id = a."academicoNatEstadoId"
	JOIN (SELECT o2."academicoId", max(o2."ocorrenciaSequencia") AS ult FROM ocorrencia o2 GROUP BY o2."academicoId")
    	     ult_o ON ult_o.ult = o."ocorrenciaSequencia" AND (ult_o."academicoId" = a."academicoId")
    WHERE
	(
		(a."academicoAnoIngresso" > 2000)
		AND a."academicoCpf" IS NOT NULL
		AND trim(both ' ' from a."academicoCpf") <> ''
		AND a."academicoNome" IS NOT NULL
		AND trim(both ' ' from a."academicoNome") <> ''
		AND a."academicoCpf" = cpf
		AND date_part('Year',o."ocorrenciaCreateDate") > (date_part('Year', current_date)-2)
		AND tp."tipoSituacaoTipo" <> 'ING'
	)
    order by a."academicoAnoIngresso" DESC, a."academicoId" DESC, o."ocorrenciaSequencia" DESC;

END;
$$;

alter function busca_discentes_bolsas(varchar) owner to postgres;

