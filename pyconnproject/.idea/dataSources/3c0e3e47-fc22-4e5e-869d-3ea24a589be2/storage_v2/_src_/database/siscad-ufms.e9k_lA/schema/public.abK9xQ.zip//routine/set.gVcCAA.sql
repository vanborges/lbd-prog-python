create function set() returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE
       P RECORD;
       ofertaId INTEGER;
       cursoId INTEGER;
       cursoSequencia INTEGER;
       turmaId INTEGER;
       texto TEXT;
BEGIN

  FOR P IN
    SELECT "ofertaId","cursoId", "cursoSequencia","turmaId"
    FROM "cursoTurma"
  LOOP
      ofertaId=P."ofertaId";
      cursoId=P."cursoId";
      cursoSequencia=P."cursoSequencia";
      turmaId=P."turmaId";

      texto := '
      update "cursoTurma"
      set "cursoTurmaId" = nextval(''"cursoTurma_cursoTurmaId_seq"'')
      where "ofertaId" = ' || cast(ofertaId as varchar(15))|| '
       and  "cursoId" = ' || cast(cursoId as varchar(15)) || '
       and  "cursoSequencia" = ' || cast(cursoSequencia as varchar(15)) || '
       and  "turmaId" = ' || cast(turmaId as varchar(15)) || '';

     RAISE NOTICE '%', texto;

     EXECUTE (texto);

  END LOOP;

RETURN 1;
END;
$$;

alter function set() owner to postgres;

