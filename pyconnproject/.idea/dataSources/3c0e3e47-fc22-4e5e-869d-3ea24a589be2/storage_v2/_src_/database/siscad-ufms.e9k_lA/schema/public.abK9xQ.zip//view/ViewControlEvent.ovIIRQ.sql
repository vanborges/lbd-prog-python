create view "ViewControlEvent"("ViewControlEventId", "ViewControlEventEventName", "ViewControlEventEventText",
                               "ViewControlEventControlId", "ViewControlEventControlText",
                               "ViewControlEventControlDataInit", "ViewControlEventControlDataEnd",
                               "ViewControlEventControlHoraInit", "ViewControlEventControlHoraEnd",
                               "ViewControlEventRuleId", "ViewControlEventRuleText") as
SELECT ev."eventId"                    AS "ViewControlEventId",
       ev."eventName"                  AS "ViewControlEventEventName",
       ev."eventText"                  AS "ViewControlEventEventText",
       vcontrolregra."controlId"       AS "ViewControlEventControlId",
       vcontrolregra."controlText"     AS "ViewControlEventControlText",
       vcontrolregra."controlDataInit" AS "ViewControlEventControlDataInit",
       vcontrolregra."controlDataEnd"  AS "ViewControlEventControlDataEnd",
       vcontrolregra."controlHoraInit" AS "ViewControlEventControlHoraInit",
       vcontrolregra."controlHoraEnd"  AS "ViewControlEventControlHoraEnd",
       vcontrolregra."ruleId"          AS "ViewControlEventRuleId",
       vcontrolregra."ruleText"        AS "ViewControlEventRuleText"
FROM (event ev
         LEFT JOIN (SELECT r."ruleId",
                           r."ruleText",
                           co."controlId",
                           co."controlText",
                           to_char((co."controlDataInit")::timestamp with time zone,
                                   'DD/MM/YYYY'::text)                                                  AS "controlDataInit",
                           to_char((co."controlDataEnd")::timestamp with time zone,
                                   'DD/MM/YYYY'::text)                                                  AS "controlDataEnd",
                           to_char((co."controlHoraInit")::interval, 'hh24:mm'::text)                   AS "controlHoraInit",
                           to_char((co."controlHoraEnd")::interval, 'hh24:mm'::text)                    AS "controlHoraEnd",
                           co."eventId"
                    FROM (control co
                             JOIN rule r ON ((co."controlId" = r."controlId")))
                    WHERE (((('now'::text)::date > co."controlDataInit") OR
                            ((('now'::text)::date = co."controlDataInit") AND
                             (('now'::text)::time with time zone >= (co."controlHoraInit")::time with time zone))) AND
                           ((('now'::text)::date < co."controlDataEnd") OR
                            ((('now'::text)::date = co."controlDataEnd") AND
                             (('now'::text)::time with time zone <= (co."controlHoraEnd")::time with time zone))) AND
                           (co."controlActive" IS TRUE))) vcontrolregra ON ((ev."eventId" = vcontrolregra."eventId")));

alter table "ViewControlEvent"
    owner to postgres;

