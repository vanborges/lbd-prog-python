create view "ViewAcademicoTurmaDisciplina"("ViewAcademicoTurmaDisciplinaCursoCodigo",
                                           "ViewAcademicoTurmaDisciplinaCursoNome",
                                           "ViewAcademicoTurmaDisciplinaDisciplinaCodigo",
                                           "ViewAcademicoTurmaDisciplinaDisciplinaNome",
                                           "ViewAcademicoTurmaDisciplinaDisciplinaCarga",
                                           "ViewAcademicoTurmaDisciplinaDisciplinaSituacao",
                                           "ViewAcademicoTurmaDisciplinaId", "ViewAcademicoTurmaDisciplinaAno",
                                           "ViewAcademicoTurmaDisciplinaSem", "centroId") as
SELECT DISTINCT c."cursoCodigo"        AS "ViewAcademicoTurmaDisciplinaCursoCodigo",
                c."cursoNome"          AS "ViewAcademicoTurmaDisciplinaCursoNome",
                d."disciplinaCodigo"   AS "ViewAcademicoTurmaDisciplinaDisciplinaCodigo",
                d."disciplinaNome"     AS "ViewAcademicoTurmaDisciplinaDisciplinaNome",
                d."disciplinaCarga"    AS "ViewAcademicoTurmaDisciplinaDisciplinaCarga",
                d."disciplinaSituacao" AS "ViewAcademicoTurmaDisciplinaDisciplinaSituacao",
                g."gradeId"            AS "ViewAcademicoTurmaDisciplinaId",
                a."ANO"                AS "ViewAcademicoTurmaDisciplinaAno",
                a."SEM"                AS "ViewAcademicoTurmaDisciplinaSem",
                de."centroId"
FROM ((((curso c
    JOIN grade g ON ((c."cursoId" = g."cursoId")))
    JOIN disciplina d ON ((g."disciplinaId" = d."disciplinaId")))
    JOIN departamento de ON ((d."departamentoId" = de."departamentoId")))
         JOIN "academicoTurma" a ON ((d."disciplinaId" = a."disciplinaId")))
WHERE (((a."CURDISC")::bpchar = c."cursoCodigo") AND
       (((c."cursoAnoIni" * 10) + c."cursoSemIni") <= ((a."ANO" * 10) + a."SEM")) AND
       (((c."cursoAnoFim" * 10) + c."cursoSemFim") >= ((a."ANO" * 10) + a."SEM")))
ORDER BY c."cursoCodigo", c."cursoNome", d."disciplinaCodigo", d."disciplinaNome", d."disciplinaCarga",
         d."disciplinaSituacao", g."gradeId", a."ANO", a."SEM", de."centroId";

alter table "ViewAcademicoTurmaDisciplina"
    owner to postgres;

