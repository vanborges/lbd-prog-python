create view "ViewDocenteTurma"("ViewDocenteTurmaDocenteId", "ViewDocenteTurmaTurmaId", "ViewDocenteTurmaOfertaId",
                               "ViewDocenteTurmaTurmaAno", "ViewDocenteTurmaTurmaSemestre") as
    (SELECT DISTINCT dt."docenteId"    AS "ViewDocenteTurmaDocenteId",
                     t."turmaId"       AS "ViewDocenteTurmaTurmaId",
                     t."ofertaId"      AS "ViewDocenteTurmaOfertaId",
                     t."turmaAno"      AS "ViewDocenteTurmaTurmaAno",
                     t."turmaSemestre" AS "ViewDocenteTurmaTurmaSemestre"
     FROM ("docenteTurma" dt
              JOIN turma t ON ((dt."turmaId" = t."turmaId")))
     WHERE (t."turmaIsFather" IS FALSE)
     ORDER BY dt."docenteId", t."turmaId", t."ofertaId", t."turmaAno", t."turmaSemestre")
    UNION
    (SELECT DISTINCT dt."docenteId"          AS "ViewDocenteTurmaDocenteId",
                     teorica."turmaIdFilho"  AS "ViewDocenteTurmaTurmaId",
                     teorica."ofertaId"      AS "ViewDocenteTurmaOfertaId",
                     teorica."turmaAno"      AS "ViewDocenteTurmaTurmaAno",
                     teorica."turmaSemestre" AS "ViewDocenteTurmaTurmaSemestre"
     FROM ("docenteTurma" dt
              JOIN (SELECT f."turmaId" AS "turmaIdFilho",
                           p."turmaId" AS "turmaIdPai",
                           f."ofertaId",
                           p."turmaAno",
                           p."turmaSemestre"
                    FROM (turma p
                             JOIN turma f ON ((f."turmaPai" = p."turmaId")))) teorica
                   ON ((dt."turmaId" = teorica."turmaIdPai")))
     ORDER BY dt."docenteId", teorica."turmaIdFilho", teorica."ofertaId", teorica."turmaAno", teorica."turmaSemestre");

alter table "ViewDocenteTurma"
    owner to postgres;

