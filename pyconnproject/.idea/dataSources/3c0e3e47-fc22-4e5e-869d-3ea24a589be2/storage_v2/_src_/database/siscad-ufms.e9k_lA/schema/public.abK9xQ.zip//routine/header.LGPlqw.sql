create function header(integer, integer) returns typecabecalho
    language plpgsql
as
$$
DECLARE
turmaId ALIAS FOR $1;  /* Identificador da turma */
opt     ALIAS FOR $2;  /* se opt for igual a 1 faz se a soma da carga horaria lecionada */
                       /* se opt for igual a 3 traz o SAD junto com o nome do professor */
cab typecabecalho%rowtype;
cargaHoraria numeric(4,1);
cargaHorariaSemanal numeric(4,1);
pointer record;
carga_lim char;
BEGIN


  /* buscando as informações para montar o cabeçalho */
  if opt > 10 then -- considerando que o opt com o curso tenha valor maior que 10
       select into cab
            v."ViewPlanoEnsinocentroSigla" ,   v."ViewPlanoEnsinocentroNome" ,
            v."ViewPlanoEnsinodepartamentoSigla", v."ViewPlanoEnsinodepartamentoNome",
            v."ViewPlanoEnsinodisciplinaCodigo" ,  v."ViewPlanoEnsinodisciplinaNome",
            v."ViewPlanoEnsinodisciplinaCarga",   null,
            v."ViewPlanoEnsinoturmaNome",   v."ViewPlanoEnsinoAno",
            v."ViewPlanoEnsinoofertaSemestre",   v."ViewPlanoEnsinoofertaDuracao",
            null,  v."ViewPlanoEnsinocursoCodigo",    v."ViewPlanoEnsinocursoNome", null
       from "ViewPlanoEnsino" v
       where --v."ViewPlanoEnsinoId" = turmaId and
       v."ViewPlanoEnsinoId" = opt;
  else
      select into cab
           v."ViewDiariocentroSigla" , v."ViewDiariocentroNome", v."ViewDiariodepartamentoSigla",
           v."ViewDiariodepartamentoNome", v."ViewDiariodisciplinaCodigo", v."ViewDiariodisciplinaNome",
           v."ViewDiariodisciplinaCarga", null, v."ViewDiarioturmaNome", v."ViewDiarioAno",
           v."ViewDiarioofertaSemestre", v."ViewDiarioofertaDuracao" , null, v."ViewDiariocursoCodigo",
           v."ViewDiariocursoNome", null
      from "ViewDiario" v
      where v."ViewDiarioId" = turmaId;
   end if;

  /* buscando a carga horaria do banco. */
  /*Busca saber se a carga horaria eh limitada
  select e."estruturaCargaHorariaLimitada" into carga_lim
  from estrutura e
  where e."estruturaId" in (select distinct g."estruturaId"
                           from "cursoTurma" ct join oferta o on(ct."ofertaId"=o."ofertaId")
                           join grade g on (o."gradeId" = g."gradeId")
                           where ct."turmaId" = turmaId);

  /*Carga horaria eh limitada 
  if carga_lim = 'S' then
       select (c."cursoModulo"*2) into cab."disciplinaCarga"
     	from "cursoTurma" ct join  oferta o on ct."ofertaId" = o."ofertaId" 
          join grade g on o."gradeId" = g."gradeId" 
          join curso c on g."cursoId" = c."cursoId"
        where ct."turmaId" = turmaId;

/*
     select (c."cursoModulo"*2) into cab."disciplinaCarga"
     from "cursoTurma" ct, oferta o, curso c
     where ct."ofertaId" = o."ofertaId" and
             o."cursoId" = c."cursoId" and
             o."cursoSequencia" = c."cursoSequencia" and
             ct."turmaId" = turmaId;
             
     end if;
  /* Fim da busca da carga horaria */


  /* a funçao deixa como opcao a soma da carga horaria total ja ministrada na turma. */
  if opt = 1 THEN
     select into cargaHoraria  sum(d."diaLetivoCargaHorariaDia")
     from "diaLetivo" d
     where d."turmaId" = turmaId;
     cab."diaLetivocargaHoraria" := cargaHoraria;
  end if;

  /* mostrar a carga horaria semanal usar a opcao 2 */
  if opt = 2 THEN
          SELECT into cargaHorariaSemanal (cab."disciplinaCarga" / cu."cursoModulo")
          FROM "cursoTurma" c join  oferta o on c."ofertaId" = o."ofertaId"
               join grade g on o."gradeId" = g."gradeId"
               join disciplina d on  g."disciplinaId" = d."disciplinaId"
               join curso cu on g."cursoId" = cu."cursoId"
          WHERE c."turmaId" = turmaId;
          cab."planoEnsinocargaSemanal" := cargaHorariaSemanal;
  end if;

/*
 * Modificado em 18/12/2008 por Thiago Acosta Amaral,
 *  para passar a mostrar tambem o nome dos docente que ministram apenas 
 *  aula teorica  
 */
  /* buscanco o(s) professore(s) que já ministraram naquela disciplina para aquela turma. */
  for   pointer in
  select DISTINCT dc."docenteNome",dc."docenteMatricula"
  from docente dc join "docenteTurma" dt on ( dc."docenteId" = dt."docenteId")
   join turma t on ( dt."turmaId" = t."turmaId" OR dt."turmaId" = t."turmaPai" )
  where t."turmaId" = turmaId 
  loop
     if(opt = 3)then
          if nullvalue(cab."docenteNome") then
                cab."docenteNome" := pointer."docenteMatricula" || ' - ' || pointer."docenteNome";
          else
                cab."docenteNome" := cab."docenteNome" || ' / ' || pointer."docenteMatricula" || ' - ' || pointer."docenteNome";
          end if;
     else
         if nullvalue(cab."docenteNome" ) then
               cab."docenteNome" :=  pointer."docenteNome";
         else
              cab."docenteNome" := cab."docenteNome" || ' / ' || pointer."docenteNome";
         end if;
     end if;

  end loop;

  RETURN cab;
END;

$$;

alter function header(integer, integer) owner to postgres;

