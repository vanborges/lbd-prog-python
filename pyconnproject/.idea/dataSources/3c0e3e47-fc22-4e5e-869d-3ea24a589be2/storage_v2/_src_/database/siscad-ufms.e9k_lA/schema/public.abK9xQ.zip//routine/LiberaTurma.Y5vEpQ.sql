create function "LiberaTurma"("turmaId" integer) returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE turmaId alias for $1;

BEGIN

update "academicoTurma"
set "academicoTurmaBloqueioMF" = 2,
"academicoTurmaDataBloqueio" = null,
"academicoTurmaPregSituacao" = 'MA' ,
"academicoTurmaSituacao" = 'MA',	
"academicoTurmaSeqBloqueio" = null
where "turmaId"=turmaId;

update "academicoTurmaCNTHSTNOTA"
set "academicoTurmaCNT_LIBERAD" = 2,
    "Transferido"= 2
where ("academicoTurmaCNT_ANO","academicoTurmaCNT_SEM","academicoTurmaCNT_DISC","academicoTurmaCNT_TURMA")
in
(	
select a."ANO" ,a."SEM", a."DISC", a."TURMA"
from "academicoTurma" a
where a."turmaId" = turmaId );

RETURN 1;

END;
$$;

alter function "LiberaTurma"(integer) owner to postgres;

