create function atualizadata("turmaId" integer, "dataInicio" date, "dataFim" date) returns integer
    strict
    language plpgsql
as
$$
DECLARE
pointer record;
horarioDataInicio date;
dataTemp date;
diaSemana char;
numeroSemanas integer;
countFeriado integer;
BEGIN
--  statements;
-- EXCEPTION
-- WHEN exception_name THEN
--  statements;
	if "dataFim" < "dataInicio" then
        RAISE EXCEPTION 'A dataFim não pode ser menor que a dataInicio';
    	return 0;
    end if;
    
    for pointer in 
    	SELECT h."horarioId", h."horarioDataInicio", h."horarioDataFim",  
		       h."horarioDiaSemana",    h."horarioSemanas"
		FROM horario h 
        WHERE h."turmaId" = "turmaId"    loop
        
		horarioDataInicio := pointer."horarioDataInicio"; 		
		-- se a data de inicio for menor que a data inicial do calendario
        -- atualizar.
        if  horarioDataInicio < "dataInicio" then
        	-- raise notice 'data atualizada';
        	horarioDataInicio := "dataInicio";
        end if;        

        dataTemp := horarioDataInicio;
        
        -- incrementar a data até o dia da aula.
          while TO_CHAR(dataTemp, 'D')::integer !=  pointer."horarioDiaSemana" LOOP
              -- raise notice '% -- %',dataTemp, TO_CHAR(dataTemp, 'D');        
	          dataTemp := dataTemp + 1;
          END LOOP;
          
          numeroSemanas := 1;

        -- incrementar a data até o maximo da oferta (periodo letivo)
        -- ou ate atingir o numer de semanas desejadas descontando os
        -- feriados.  
        LOOP   		
         -- raise notice 'numeroSemanas :  % pointer.horarioSemanas : %',
         -- numeroSemanas , pointer."horarioSemanas"  ;
        
		    IF dataTemp >=  "dataFim" OR 
               numeroSemanas >= pointer."horarioSemanas"	
            THEN
        		EXIT;  -- exit loop
		    END IF;
            
            -- descontando o feriado.
            
            select into countFeriado count(*)
            FROM feriado f
            WHERE f."feriadoData" = dataTemp;
            
            -- raise notice '%', countFeriado;
            
			if countFeriado = 0 then
	            numeroSemanas := numeroSemanas + 1;
            end if;
            
            dataTemp := dataTemp + 7; -- proxima semana.
            
		END LOOP;
        
          -- raise notice 'numer de semanas %', numeroSemanas;
          raise notice 'atualizar a data para o horario %  data incial % e data final %',
          pointer."horarioId", horarioDataInicio,dataTemp; 

    end loop;   
    
return 1;
END;
$$;

alter function atualizadata(integer, date, date) owner to postgres;

