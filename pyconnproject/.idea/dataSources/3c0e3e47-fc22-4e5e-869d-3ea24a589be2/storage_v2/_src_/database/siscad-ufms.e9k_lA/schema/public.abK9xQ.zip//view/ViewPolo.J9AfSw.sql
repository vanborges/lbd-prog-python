create view "ViewPolo"("ViewPoloId", "ViewPoloPoloNome", "ViewPoloCidadeId", "ViewPoloEstadoId", "ViewPoloCidadeNome",
                       "ViewPoloEstadoNome", "ViewPoloEndereco") as
SELECT p."poloId"       AS "ViewPoloId",
       p."poloNome"     AS "ViewPoloPoloNome",
       c.cidade_id      AS "ViewPoloCidadeId",
       c.estado_id      AS "ViewPoloEstadoId",
       c.descricao      AS "ViewPoloCidadeNome",
       e.descricao      AS "ViewPoloEstadoNome",
       p."poloEndereco" AS "ViewPoloEndereco"
FROM ((polo p
    JOIN pessoas.cidades c ON ((p."cidadeId" = c.cidade_id)))
         JOIN pessoas.estados e ON ((c.estado_id = e.estado_id)))
ORDER BY (upper(to_ascii((p."poloNome")::text)));

alter table "ViewPolo"
    owner to postgres;

