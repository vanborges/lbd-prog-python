create view "ViewSecretariaDepartamento"("ViewSecretariaDepartamentoId", "ViewSecretariaDepartamentoSecretariaId",
                                         "ViewSecretariaDepartamentoDepartamentoId",
                                         "ViewSecretariaDepartamentoDepartamentoSigla",
                                         "ViewSecretariaDepartamentoDepartamentoNome",
                                         "ViewSecretariaDepartamentoOfertaId", "foreignId") as
SELECT o."ofertaId"           AS "ViewSecretariaDepartamentoId",
       se."secretariaId"      AS "ViewSecretariaDepartamentoSecretariaId",
       de."departamentoId"    AS "ViewSecretariaDepartamentoDepartamentoId",
       de."departamentoSigla" AS "ViewSecretariaDepartamentoDepartamentoSigla",
       de."departamentoNome"  AS "ViewSecretariaDepartamentoDepartamentoNome",
       o."ofertaId"           AS "ViewSecretariaDepartamentoOfertaId",
       se."secretariaId"      AS "foreignId"
FROM (((((oferta o
    JOIN grade g ON ((o."gradeId" = g."gradeId")))
    JOIN disciplina di ON ((g."disciplinaId" = di."disciplinaId")))
    JOIN departamento de ON ((di."departamentoId" = de."departamentoId")))
    JOIN "secretariaDepartamento" sd ON ((de."departamentoId" = sd."departamentoId")))
         JOIN secretaria se ON ((sd."secretariaId" = se."secretariaId")))
WHERE ((se."secretariaActive" IS TRUE) AND (sd."secretariaDepartamentoActive" IS TRUE));

alter table "ViewSecretariaDepartamento"
    owner to postgres;

