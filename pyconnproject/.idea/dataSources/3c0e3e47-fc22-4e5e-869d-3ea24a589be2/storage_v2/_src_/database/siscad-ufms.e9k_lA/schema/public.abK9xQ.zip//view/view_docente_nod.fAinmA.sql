create view view_docente_nod(doc_nome) as
SELECT d."docenteNome" AS doc_nome
FROM docente d
WHERE ((d."docenteSituacao" = ANY (ARRAY ['01'::bpchar, '99'::bpchar])) AND
       (d."docenteDepartamento" = ANY (ARRAY ['0108'::bpchar, '1101'::bpchar, '1102'::bpchar, '1103'::bpchar])))
ORDER BY d."docenteNome";

alter table view_docente_nod
    owner to postgres;

