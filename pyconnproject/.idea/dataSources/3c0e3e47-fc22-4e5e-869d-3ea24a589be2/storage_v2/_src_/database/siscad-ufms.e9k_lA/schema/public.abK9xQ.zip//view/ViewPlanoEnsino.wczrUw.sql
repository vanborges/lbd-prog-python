create view "ViewPlanoEnsino"("ViewPlanoEnsinoId", "ViewPlanoEnsinodisciplinaCodigo", "ViewPlanoEnsinodisciplinaNome",
                              "ViewPlanoEnsinodisciplinaCarga", "ViewPlanoEnsinoturmaTipo", "ViewPlanoEnsinoturmaNome",
                              "foreignId", "ViewPlanoEnsinoofertaId", "ViewPlanoEnsinoAno",
                              "ViewPlanoEnsinoofertaSemestre", "ViewPlanoEnsinoofertaDuracao",
                              "ViewPlanoEnsinocursoCodigo", "ViewPlanoEnsinocursoNome",
                              "ViewPlanoEnsinodepartamentoSigla", "ViewPlanoEnsinodepartamentoNome",
                              "ViewPlanoEnsinocentroId", "ViewPlanoEnsinocentroSigla", "ViewPlanoEnsinocentroNome",
                              "ViewPlanoEnsinoplanoEnsinoId", "ViewPlanoEnsinoturmaBloqueio",
                              "ViewPlanoEnsinoAprovcolegiado", "ViewPlanoEnsinoAprovdepto",
                              "ViewPlanoEnsinodataUltimaAlteracao", "ViewPlanoEnsinousrName", "ViewPlanoEnsinoLiberado",
                              "ViewPlanoEnsinoCursoTurmaId") as
    (SELECT DISTINCT turma."turmaId"                                       AS "ViewPlanoEnsinoId",
                     disciplina."disciplinaCodigo"                         AS "ViewPlanoEnsinodisciplinaCodigo",
                     disciplina."disciplinaNome"                           AS "ViewPlanoEnsinodisciplinaNome",
                     disciplina."disciplinaCarga"                          AS "ViewPlanoEnsinodisciplinaCarga",
                     turma."turmaTipo"                                     AS "ViewPlanoEnsinoturmaTipo",
                     turma."turmaNome"                                     AS "ViewPlanoEnsinoturmaNome",
                     "docenteTurma"."docenteId"                            AS "foreignId",
                     oferta."ofertaId"                                     AS "ViewPlanoEnsinoofertaId",
                     oferta."ofertaAno"                                    AS "ViewPlanoEnsinoAno",
                     oferta."ofertaSemestre"                               AS "ViewPlanoEnsinoofertaSemestre",
                     oferta."ofertaDuracao"                                AS "ViewPlanoEnsinoofertaDuracao",
                     curso."cursoCodigo"                                   AS "ViewPlanoEnsinocursoCodigo",
                     curso."cursoNome"                                     AS "ViewPlanoEnsinocursoNome",
                     departamento."departamentoSigla"                      AS "ViewPlanoEnsinodepartamentoSigla",
                     departamento."departamentoNome"                       AS "ViewPlanoEnsinodepartamentoNome",
                     centro."centroId"                                     AS "ViewPlanoEnsinocentroId",
                     centro."centroSigla"                                  AS "ViewPlanoEnsinocentroSigla",
                     centro."centroNome"                                   AS "ViewPlanoEnsinocentroNome",
                     turma."planoEnsinoId"                                 AS "ViewPlanoEnsinoplanoEnsinoId",
                     ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint) AS "ViewPlanoEnsinoturmaBloqueio",
                     "planoEnsinoAprovacao"."dataAprovacaoColegiado"       AS "ViewPlanoEnsinoAprovcolegiado",
                     "planoEnsino"."planoEnsinoAprovdepto"                 AS "ViewPlanoEnsinoAprovdepto",
                     "planoEnsino"."planoEnsinoDataUltimaAlteracao"        AS "ViewPlanoEnsinodataUltimaAlteracao",
                     usr."usrName"                                         AS "ViewPlanoEnsinousrName",
                     "planoEnsino"."planoEnsinoLiberado"                   AS "ViewPlanoEnsinoLiberado",
                     "cursoTurma"."cursoTurmaId"                           AS "ViewPlanoEnsinoCursoTurmaId"
     FROM (((((((((((("docenteTurma"
         JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaId")))
         JOIN "cursoTurma" ON (("cursoTurma"."turmaId" = turma."turmaId")))
         JOIN oferta ON ((turma."ofertaId" = oferta."ofertaId")))
         JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
         JOIN curso ON ((("cursoTurma"."cursoCodigo")::bpchar = curso."cursoCodigo")))
         JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
         JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
         JOIN centro ON ((departamento."centroId" = centro."centroId")))
         LEFT JOIN "planoEnsino" ON ((turma."planoEnsinoId" = "planoEnsino"."planoEnsinoId")))
         LEFT JOIN usr ON (("planoEnsino"."usrId" = usr."usrId")))
         LEFT JOIN "usrSystem" ON ((usr."usrId" = "usrSystem"."usrId")))
              LEFT JOIN "planoEnsinoAprovacao"
                        ON ((("planoEnsino"."planoEnsinoId" = "planoEnsinoAprovacao"."planoEnsinoId") AND
                             ("cursoTurma"."cursoTurmaId" = "planoEnsinoAprovacao"."cursoTurmaId"))))
     WHERE (turma."turmaIsFather" IS FALSE)
     ORDER BY turma."turmaId", disciplina."disciplinaCodigo", disciplina."disciplinaNome", disciplina."disciplinaCarga",
              turma."turmaTipo", turma."turmaNome", "docenteTurma"."docenteId", oferta."ofertaId", oferta."ofertaAno",
              oferta."ofertaSemestre", oferta."ofertaDuracao", curso."cursoNome", departamento."departamentoSigla",
              departamento."departamentoNome", centro."centroSigla", centro."centroNome", turma."planoEnsinoId",
              ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint), "planoEnsinoAprovacao"."dataAprovacaoColegiado",
              "planoEnsino"."planoEnsinoAprovdepto", "planoEnsino"."planoEnsinoDataUltimaAlteracao", usr."usrName",
              curso."cursoCodigo", "planoEnsino"."planoEnsinoLiberado", "cursoTurma"."cursoTurmaId", centro."centroId")
    UNION
    (SELECT DISTINCT turma."turmaId"                                       AS "ViewPlanoEnsinoId",
                     disciplina."disciplinaCodigo"                         AS "ViewPlanoEnsinodisciplinaCodigo",
                     disciplina."disciplinaNome"                           AS "ViewPlanoEnsinodisciplinaNome",
                     disciplina."disciplinaCarga"                          AS "ViewPlanoEnsinodisciplinaCarga",
                     turma."turmaTipo"                                     AS "ViewPlanoEnsinoturmaTipo",
                     turma."turmaNome"                                     AS "ViewPlanoEnsinoturmaNome",
                     "docenteTurma"."docenteId"                            AS "foreignId",
                     oferta."ofertaId"                                     AS "ViewPlanoEnsinoofertaId",
                     oferta."ofertaAno"                                    AS "ViewPlanoEnsinoAno",
                     oferta."ofertaSemestre"                               AS "ViewPlanoEnsinoofertaSemestre",
                     oferta."ofertaDuracao"                                AS "ViewPlanoEnsinoofertaDuracao",
                     curso."cursoCodigo"                                   AS "ViewPlanoEnsinocursoCodigo",
                     curso."cursoNome"                                     AS "ViewPlanoEnsinocursoNome",
                     departamento."departamentoSigla"                      AS "ViewPlanoEnsinodepartamentoSigla",
                     departamento."departamentoNome"                       AS "ViewPlanoEnsinodepartamentoNome",
                     centro."centroId"                                     AS "ViewPlanoEnsinocentroId",
                     centro."centroSigla"                                  AS "ViewPlanoEnsinocentroSigla",
                     centro."centroNome"                                   AS "ViewPlanoEnsinocentroNome",
                     turma."planoEnsinoId"                                 AS "ViewPlanoEnsinoplanoEnsinoId",
                     ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint) AS "ViewPlanoEnsinoturmaBloqueio",
                     "planoEnsinoAprovacao"."dataAprovacaoColegiado"       AS "ViewPlanoEnsinoAprovcolegiado",
                     "planoEnsino"."planoEnsinoAprovdepto"                 AS "ViewPlanoEnsinoAprovdepto",
                     "planoEnsino"."planoEnsinoDataUltimaAlteracao"        AS "ViewPlanoEnsinodataUltimaAlteracao",
                     usr."usrName"                                         AS "ViewPlanoEnsinousrName",
                     "planoEnsino"."planoEnsinoLiberado"                   AS "ViewPlanoEnsinoLiberado",
                     "cursoTurma"."cursoTurmaId"                           AS "ViewPlanoEnsinoCursoTurmaId"
     FROM (((((((((((("docenteTurma"
         JOIN turma ON (("docenteTurma"."turmaId" = turma."turmaPai")))
         JOIN "cursoTurma" ON (("cursoTurma"."turmaId" = turma."turmaId")))
         JOIN oferta ON ((turma."ofertaId" = oferta."ofertaId")))
         JOIN grade ON ((oferta."gradeId" = grade."gradeId")))
         JOIN curso ON ((("cursoTurma"."cursoCodigo")::bpchar = curso."cursoCodigo")))
         JOIN disciplina ON ((grade."disciplinaId" = disciplina."disciplinaId")))
         JOIN departamento ON ((disciplina."departamentoId" = departamento."departamentoId")))
         JOIN centro ON ((departamento."centroId" = centro."centroId")))
         LEFT JOIN "planoEnsino" ON ((turma."planoEnsinoId" = "planoEnsino"."planoEnsinoId")))
         LEFT JOIN usr ON (("planoEnsino"."usrId" = usr."usrId")))
         LEFT JOIN "usrSystem" ON ((usr."usrId" = "usrSystem"."usrId")))
              LEFT JOIN "planoEnsinoAprovacao"
                        ON ((("planoEnsino"."planoEnsinoId" = "planoEnsinoAprovacao"."planoEnsinoId") AND
                             ("cursoTurma"."cursoTurmaId" = "planoEnsinoAprovacao"."cursoTurmaId"))))
     WHERE (turma."turmaIsFather" IS FALSE)
     ORDER BY turma."turmaId", disciplina."disciplinaCodigo", disciplina."disciplinaNome", disciplina."disciplinaCarga",
              turma."turmaTipo", turma."turmaNome", "docenteTurma"."docenteId", oferta."ofertaId", oferta."ofertaAno",
              oferta."ofertaSemestre", oferta."ofertaDuracao", curso."cursoNome", departamento."departamentoSigla",
              departamento."departamentoNome", centro."centroSigla", centro."centroNome", turma."planoEnsinoId",
              ("planoEnsino"."planoEnsinoLiberado" - (1)::smallint), "planoEnsinoAprovacao"."dataAprovacaoColegiado",
              "planoEnsino"."planoEnsinoAprovdepto", "planoEnsino"."planoEnsinoDataUltimaAlteracao", usr."usrName",
              curso."cursoCodigo", "planoEnsino"."planoEnsinoLiberado", "cursoTurma"."cursoTurmaId", centro."centroId");

alter table "ViewPlanoEnsino"
    owner to postgres;

