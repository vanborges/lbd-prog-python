create function stand_by() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE EXCEPTION 'Não será permitido nehuma alteração (INSERT, UPDATE OU DELETE)nesta 
    tabela, para garantir que mesmo existindo no banco seus dados conituam imutaveis.';
    RETURN NULL;
END;
$$;

alter function stand_by() owner to postgres;

