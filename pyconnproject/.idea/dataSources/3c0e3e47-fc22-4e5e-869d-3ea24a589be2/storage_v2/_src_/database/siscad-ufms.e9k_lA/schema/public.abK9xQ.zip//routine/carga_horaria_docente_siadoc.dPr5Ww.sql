create function carga_horaria_docente_siadoc(siape character varying, ano integer) returns SETOF record
    language plpgsql
as
$$
BEGIN

RETURN QUERY

    SELECT distinct d."disciplinaId",
           d."disciplinaCodigo",
           d."disciplinaNome",
           t."DP_TURMAF",
           t."turmaAno",
           t."turmaSemestre",
           dt."docenteTurmaChMinistrada",
           c."cursoNome",
           COALESCE(h."horarioContaCargaHoraria", b'1') as "horarioContaCargaHoraria",
           (
           select count(*) 
           from "academicoTurma" act where act."turmaId" = t."turmaId"
           ) + (
           select count(*) 
           from "academicoTurma" act
           join "turma" t3 on t3."turmaId" = act."turmaId"
            where t3."turmaPai" = t."turmaId"
           ) as "alunosMatriculados"
    FROM public."docenteTurma" dt
        JOIN public.turma t on t."turmaId" = dt."turmaId"
        JOIN public.oferta o on t."ofertaId" = o."ofertaId"
        JOIN public.grade g on o."gradeId" = g."gradeId"
        JOIN public.disciplina d on g."disciplinaId" = d."disciplinaId"
        JOIN public.docente doc on dt."docenteId" = doc."docenteId"
        LEFT JOIN public.horario h on dt."docenteTurmaId" = h."docenteTurmaId"
        JOIN public.curso c on o."_cursoId" = c."cursoId"
    WHERE doc."docenteSiape" = siape
          AND t."turmaAno" = ano
    ORDER BY d."disciplinaNome", t."DP_TURMAF";

END;
$$;

comment on function carga_horaria_docente_siadoc(varchar, integer) is 'Função para buscar a carga horária ministrada por docente/ano.
Utilizada no sistema de avaliação docente (SIADOC).';

alter function carga_horaria_docente_siadoc(varchar, integer) owner to postgres;

