create function frequenciaaula(integer, integer, integer, date, date, character, integer, real) returns integer
    language plpgsql
as
$$
DECLARE
    turmaId ALIAS FOR $1;
    diaLetivoId ALIAS FOR $2;
    academicoTurmaId ALIAS FOR $3;
    dt_ini ALIAS FOR $4;
    dt_fim ALIAS FOR $5;
    freq ALIAS FOR $6;
    opt ALIAS FOR $7;
    carga_horaria_total ALIAS FOR $8;
    --carga_horaria_total float4; -- integer;
    pointer RECORD;
    ch integer;
    ch_total integer;
    str bit(2)[];
    str_aux bit(2)[];
    vet_aux bit(2)[];
    varaux bit(2);
    num_faltas integer;
    num_pres integer;
    acdTurmaId integer;
    num_pres_atual integer;
    num_faltas_atual integer;
    sit char(2);
    sit_antiga char(2);
    num_faltas_aux integer;
    num_pres_aux integer;
    carga_horaria_fornecida real;
    first bool; /* variavel de controle */
    i smallint; /* contador */
    sql text; /* armazena o sql para a consulta */
    perc real;
BEGIN
     /*
       Observação: a consulta usada para listar os academicos para serem
       lançacas presenças/ausencias supoe que academicos RN não tenha nehum
       registro na tabela frequencia.
     */

     if opt = 1 then
        sql := ' and d."turmaId" = ' || turmaId;
     elseif opt = 4 then
        sql := ' and d."turmaId"          = ' || turmaId ||
               ' and a."academicoTurmaId" = ' || academicoTurmaId ;
     elseif opt = 2 then
        sql := 'and d."turmaId" = ' || turmaId || ' and d."diaLetivoId" =

' || diaLetivoId;
     elseif opt = 5 then
        sql := ' and a."academicoTurmaId" = ' || academicoTurmaId ||
               ' and d."diaLetivoId"      = ' || diaLetivoId;
     elseif opt = 3 then
        sql := ' and d."turmaId" = '            || turmaId ||
               ' and d."diaLetivoData" >= '''   || dt_ini  ||
               ''' and d."diaLetivoData" <= ''' || dt_fim  || '''';
     elseif opt = 6 then
        sql := ' and a."academicoTurmaId" = '  || academicoTurmaId ||
               ' and d."diaLetivoData" >= '''  || dt_ini           ||
               ''' and d."diaLetivoData" <= '''|| dt_fim           ||

'''';
     end if;

     sql := 'select a."academicoTurmaId", d."diaLetivoId",

d."diaLetivoCargaHorariaDia",
                    a."academicoTurmaFaltas" ,

a."academicoTurmaPresenca",
                    NULL::bit [] AS "frequenciaValor", 0 as aux, a."academicoTurmaSituacao",
                    a."academicoTurmaBloqueioMF"
             from "diaLetivo" d join "academicoTurma" a using ("turmaId")
             where ( (a."academicoTurmaTipoDependencia"!=''RN'' or

a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) '
                    || sql ||
             ' EXCEPT
              select a."academicoTurmaId", d."diaLetivoId",

d."diaLetivoCargaHorariaDia",
                    a."academicoTurmaFaltas" ,

a."academicoTurmaPresenca",
                    NULL::bit [] AS "frequenciaValor", 0 as aux, a."academicoTurmaSituacao",a."academicoTurmaBloqueioMF"
             from "diaLetivo" d natural join frequencia f natural join

"academicoTurma" a
             where ( (a."academicoTurmaTipoDependencia"!=''RN'' or

a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) '
                    || sql ||
             ' union
             select a."academicoTurmaId", d."diaLetivoId",

d."diaLetivoCargaHorariaDia",
                    a."academicoTurmaFaltas" ,

a."academicoTurmaPresenca",f."frequenciaValor" AS "frequenciaValor",1 as

aux, a."academicoTurmaSituacao",a."academicoTurmaBloqueioMF"
             from "diaLetivo" d natural join frequencia f natural join

"academicoTurma" a
             where ((a."academicoTurmaTipoDependencia"!=''RN'' or

a."academicoTurmaTipoDependencia" is null ) and a."academicoTurmaBloqueioMF" = 2 ) '
                   || sql ;


     /*Inicializando*/
     num_faltas:=0;
     num_faltas_atual:=0;
     num_pres_atual:=0;
     num_pres:=0;
     sit=' ';

     /*Inserindo o primeiro valor no vetor de bits*/
     IF freq='P' OR  freq='p' THEN
        str_aux := ARRAY['10'];
        varaux := B'10';
     ELSEIF freq='F' OR freq='f' THEN
        str_aux := ARRAY['01'];
        varaux := B'01';
     ELSE
        str_aux := ARRAY['00'];
        varaux := B'00';
     END IF;
     acdTurmaId:=NULL;


     /*TODOS<->TODAS AULAS*/
     IF opt=1 THEN

        select sum(d."diaLetivoCargaHorariaDia") into carga_horaria_fornecida
        from "diaLetivo" d
        where d."turmaId"=turmaId;

        IF freq='P' OR freq='p' THEN
            num_pres:=carga_horaria_fornecida;
            perc:=0;
         ELSEIF freq='F' OR freq='f' THEN
            num_faltas:=carga_horaria_fornecida;
            sit='RF';
            perc:=100;
         ELSE
            num_faltas:=0;
            num_pres:=0;
         END IF;



      FOR pointer IN EXECUTE( sql )  LOOP
              /*Atualizando o número de Faltas,Presenças do acadêmico

além da sua situação*/

              IF nullvalue(acdTurmaId) THEN /*Primeiro Acadêmico*/

                 acdTurmaId:=pointer."academicoTurmaId";

                 sit:=pointer."academicoTurmaSituacao";

                 if (perc>25) then
				    sit='RF';
			     else
			        if (sit='RF') then
					   sit=' ';	
                    end if;
                 end if;			
			

                 update "academicoTurma" set

"academicoTurmaFaltas"=num_faltas ,

"academicoTurmaPresenca"=num_pres,"academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=acdTurmaId;

              ELSEIF(acdTurmaId!=pointer."academicoTurmaId") THEN

                 acdTurmaId:=pointer."academicoTurmaId";


                 sit:=pointer."academicoTurmaSituacao";

                 if (perc>25) then
				    sit='RF';
			     else
			        if (sit='RF') then
					   sit=' ';	
                    end if;
                 end if;			



                 update "academicoTurma" set

"academicoTurmaFaltas"=num_faltas ,

"academicoTurmaPresenca"=num_pres,"academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=acdTurmaId;

              ELSE
              END IF;

              /*Carga Horaria Do Dia*/
              ch:=ceil(pointer."diaLetivoCargaHorariaDia");
              str = NULL;
              IF ch>0 THEN
                 str = str_aux;
                  /*Criando Vetor de Frequencia*/
                  FOR i IN 1..ch-1 LOOP
                     str := array_append(str,varaux);
                  END LOOP;
              END IF;

              /*Verifica se eh INSERT ou UPDATE*/
              IF pointer."aux"=1 THEN /*UPDATE*/
                 update "frequencia" set "frequenciaValor"=str where

"frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and

"frequencia"."diaLetivoId"=pointer."diaLetivoId";
              ELSE
                 insert into "frequencia"

("academicoTurmaId","diaLetivoId","frequenciaValor") values

(pointer."academicoTurmaId",pointer."diaLetivoId",str);
              END IF;
          END LOOP;

   /*TODOS <-> AULA SELECIONADA OU UM <-> AULA SELECIONADA*/
   ELSEIF opt=2 or opt=5 THEN

      first := false; /* p/ marcar o codigo que deve ser executado

somente uma vez.*/
      FOR pointer IN EXECUTE( sql )  LOOP
          IF  first = FALSE  THEN /* Este codigo e para ser executado uma

vez ("desempenho")*/
             first := true;
             /*Carga Horaria Do Dia*/
             ch:=ceil(pointer."diaLetivoCargaHorariaDia");
             str = NULL;
             IF ch>0 THEN
                str = str_aux;
                /*Criando Vetor de FrequenciaAux*/
                FOR i IN 1..ch-1 LOOP
                   str := array_append(str,varaux);
                END LOOP;
              END IF;
          END IF;

          /*Verifica se eh INSERT ou UPDATE*/
          IF pointer."aux"=1 THEN /*UPDATE*/
             update "frequencia" set "frequenciaValor"=str where

"frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and

"frequencia"."diaLetivoId"=pointer."diaLetivoId";
          ELSE
             insert into "frequencia"

("academicoTurmaId","diaLetivoId","frequenciaValor") values

(pointer."academicoTurmaId",pointer."diaLetivoId",str);
          END IF;

          /* Vetor auxiliar para se deslocar no registro de frequencia */
          str_aux := pointer."frequenciaValor";

          /* Atribui uma flag p/ sinalizar o fim do vetor */
          str_aux := array_append(str_aux,B'11');
          i := 1; /* o vetor começa na posição um */

          /* Iniciando as variaveis */
          num_faltas := 0;
          num_pres   := 0;

          --RAISE NOTICE '%',str_aux;
          /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia

letivo X*/
          WHILE str_aux[i] != B'11' LOOP
             if(str_aux[i] = B'01') then /* se falta */
                num_faltas:=num_faltas+1;
             elseif (str_aux[i] = B'10') then /* se presença */
                num_pres:=num_pres+1;
             elseif (str_aux[i] = B'00') then

             end if;
             i := i + 1;
          END LOOP;

          /*Atualizando o número de F/P e a Situação do acadêmico*/
          num_faltas_atual := pointer."academicoTurmaFaltas" -

num_faltas;
          num_pres_atual   := pointer."academicoTurmaPresenca" -

num_pres;

          /* Se houve alteração no nº de faltas e/ou presença fazer

update */

             if varaux = B'01' then
                num_faltas_atual := num_faltas_atual + ch;
             elseif varaux = B'10' then
                num_pres_atual := num_pres_atual + ch;
             end if;

             if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
                sit := 'RF';
                update "academicoTurma" set
                    "academicoTurmaFaltas"=num_faltas_atual ,
                    "academicoTurmaPresenca"=num_pres_atual,
                    "academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
             else

                sit:=pointer."academicoTurmaSituacao";

                if (sit='RF') then
				   sit=' ';	
                end if;

                 update "academicoTurma" set
                    "academicoTurmaFaltas"=num_faltas_atual ,
                    "academicoTurmaPresenca"=num_pres_atual,
                    "academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
             end if;

      END LOOP;
   /*TODOS <-> INTERVALO DE AULA  OU UM <-> INTERVALO DE AULA*/
   ELSEIF opt = 3 or opt = 6 THEN
      ch_total   := 0;
      acdTurmaId := 0;
      num_faltas := 0;
      num_pres   := 0;
      vet_aux    := ARRAY['00'];

      FOR pointer IN EXECUTE( sql )  LOOP
          /*Carga Horaria Do Dia*/
          ch:=ceil(pointer."diaLetivoCargaHorariaDia");

          str = NULL;

          IF ch>0 THEN
             str = str_aux;
             /*Criando Vetor de FrequenciaAux*/
             FOR i IN 1..ch-1 LOOP
                 str := array_append(str,varaux);
             END LOOP;
          END IF;

          /*Verifica se eh INSERT ou UPDATE*/
          IF pointer."aux"=1 THEN /*UPDATE*/
             update "frequencia" set "frequenciaValor"=str where
             "frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and
             "frequencia"."diaLetivoId"=pointer."diaLetivoId";
          ELSE
              insert into "frequencia" ("academicoTurmaId","diaLetivoId","frequenciaValor") values
                                       (pointer."academicoTurmaId",pointer."diaLetivoId",str);
          END IF;

          if (acdTurmaId != 0) AND (acdTurmaId != pointer."academicoTurmaId") then
             /*Mudou o acadêmico*/
             /* Atribui uma flag p/ sinalizar o fim do vetor */
             vet_aux := array_append(vet_aux,B'11');
             i := 1; /* o vetor começa na posição um */
             /* Iniciando as variaveis */
             num_faltas := 0;
             num_pres   := 0;
             /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia letivo X*/
             WHILE vet_aux[i] != B'11' LOOP
                if(vet_aux[i] = B'01') then
                   num_faltas:=num_faltas+1;
                elseif (vet_aux[i] = B'10') then
                   num_pres:=num_pres+1;
                end if;
                i := i + 1;
             END LOOP;
             /*Atualizando o número de F/P e a Situação do acadêmico*/
             num_faltas_atual := num_faltas_atual - num_faltas;
             num_pres_atual   := num_pres_atual - num_pres;

             /* Se houve alteração no nº de faltas e/ou presença fazer update */
             if varaux = B'01' then
                num_faltas_atual := num_faltas_atual + ch_total;
             elseif varaux = B'10' then
                num_pres_atual := num_pres_atual + ch_total;
             end if;

             if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
               sit := 'RF';
               update "academicoTurma" set
               "academicoTurmaFaltas"=num_faltas_atual ,
               "academicoTurmaPresenca"=num_pres_atual,
               "academicoTurmaSituacao"=sit where
                "academicoTurma"."academicoTurmaId"= acdTurmaId;
             else
                sit:=pointer."academicoTurmaSituacao";

			    if (sit='RF') then
				  sit=' ';	
                end if;


              update "academicoTurma" set
              "academicoTurmaFaltas"=num_faltas_atual ,
              "academicoTurmaPresenca"=num_pres_atual,
              "academicoTurmaSituacao"=sit where
              "academicoTurma"."academicoTurmaId"= acdTurmaId;
            end if;
            vet_aux  := ARRAY['00'];
            ch_total := 0;
          end if;

          /* Vetor auxiliar para se deslocar no vetor de  frequencia de todos os dias*/

          /* para evitar concatenar com nulo */
          if not nullValue( pointer."frequenciaValor") then
             vet_aux := array_cat(vet_aux,pointer."frequenciaValor");
          end if;
          ch_total := ch_total + ch;
          num_faltas_atual := pointer."academicoTurmaFaltas";
          num_pres_atual   := pointer."academicoTurmaPresenca";
          acdTurmaId := pointer."academicoTurmaId";

      END LOOP;
      if not nullvalue(acdTurmaId) then
         /* Atribui uma flag p/ sinalizar o fim do vetor */
         vet_aux := array_append(vet_aux,B'11');
         i := 1; /* o vetor começa na posição um */
         /* Iniciando as variaveis */
         num_faltas := 0;
         num_pres   := 0;
         --num_faltas_atual:=0;
         --num_pres_atual:=0;
         /*Vetor auxiliar para saber sobre as P/F do acadêmico no dia

letivo X*/
         WHILE vet_aux[i] != B'11' LOOP
            if(vet_aux[i] = B'01') then
               num_faltas:=num_faltas+1;
            elseif (vet_aux[i] = B'10') then
               num_pres:=num_pres+1;
            end if;
            i := i + 1;
         END LOOP;

         /*Atualizando o número de F/P e a Situação do acadêmico*/
         num_faltas_atual := num_faltas_atual - num_faltas;
         num_pres_atual   := num_pres_atual - num_pres;

         /* Se houve alteração no nº de faltas e/ou presença fazer update

*/
         if varaux = B'01' then
            num_faltas_atual := num_faltas_atual + ch_total;
         elseif varaux = B'10' then
            num_pres_atual := num_pres_atual + ch_total;
         end if;


         if (num_faltas_atual * 100 / carga_horaria_total ) > 25 then
            sit := 'RF';
            update "academicoTurma" set
            "academicoTurmaFaltas"=num_faltas_atual ,
            "academicoTurmaPresenca"=num_pres_atual,
            "academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
         else

             sit:=pointer."academicoTurmaSituacao";
	          if (sit='RF') then
			     sit=' ';	
              end if;

            update "academicoTurma" set
              "academicoTurmaFaltas"=num_faltas_atual ,
              "academicoTurmaPresenca"=num_pres_atual,
              "academicoTurmaSituacao"=sit where

"academicoTurma"."academicoTurmaId"=pointer."academicoTurmaId";
         end if;
      end if;

   /*UM <-> TODAS AS AULAS*/
   ELSEIF opt=4 THEN
      FOR pointer IN
          select

f."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",1 as

aux
          from "diaLetivo" d join "frequencia" f
               on d."diaLetivoId"=f."diaLetivoId"
          where d."turmaId"=turmaId and

f."academicoTurmaId"=academicoTurmaId
          union
          select

a."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",0 as

aux
          from "diaLetivo" d join "academicoTurma" a
               on d."turmaId"=a."turmaId"
          where d."turmaId"=turmaId and

(a."academicoTurmaTipoDependencia"!='RN' or

a."academicoTurmaTipoDependencia" is null) and

a."academicoTurmaId"=academicoTurmaId
          EXCEPT
          select

f."academicoTurmaId",d."diaLetivoId",d."diaLetivoCargaHorariaDia",0 as

aux
          from "diaLetivo" d join "frequencia" f
                on d."diaLetivoId"=f."diaLetivoId"
          where d."turmaId"=turmaId and

f."academicoTurmaId"=academicoTurmaId

          LOOP
              /*Carga Horaria Do Dia*/
              ch:=ceil(pointer."diaLetivoCargaHorariaDia");
              acdTurmaId:=pointer."academicoTurmaId";
              str = NULL;
              IF ch>0 THEN
                 str = str_aux;
              END IF;
              /*Criando Vetor de Frequencia*/
              FOR i IN 1..ch-1 LOOP
                 str := array_append(str,varaux);
              END LOOP;

              /*Verifica se eh INSERT ou UPDATE*/
              IF pointer."aux"=1 THEN /*UPDATE*/
                 update "frequencia" set "frequenciaValor"=str where

"frequencia"."academicoTurmaId"=pointer."academicoTurmaId" and

"frequencia"."diaLetivoId"=pointer."diaLetivoId";
              ELSE
                 insert into "frequencia"

("academicoTurmaId","diaLetivoId","frequenciaValor") values

(pointer."academicoTurmaId",pointer."diaLetivoId",str);
              END IF;
          END LOOP;
          /* Se houve alteração no nº de faltas e/ou presença fazer

update */
          sit := '';


        select sum(d."diaLetivoCargaHorariaDia") into carga_horaria_fornecida
        from "diaLetivo" d
        where d."turmaId"=turmaId;



          if varaux = B'01' then
             num_faltas_atual := carga_horaria_fornecida;
             perc:=100;
             sit := 'RF';
          elseif varaux = B'10' then
             num_pres_atual := carga_horaria_fornecida;
             perc:=0;
          else
              num_faltas_atual := 0;
              num_pres_atual   := 0;
          end if;
          /*Atualizando o número de Faltas,Presenças do acadêmico além da

sua situação*/

          IF not nullvalue(acdTurmaId) THEN /*Primeiro Acadêmico*/


             select at."academicoTurmaSituacao" into sit
             from "academicoTurma" at
             where at."academicoTurmaId" =acdTurmaId;

             if (perc>25) then
			    sit='RF';
		     else
		        if (sit='RF') then
				   sit=' ';	
                end if;
             end if;			


             update "academicoTurma" set

"academicoTurmaFaltas"=num_faltas_atual ,

"academicoTurmaPresenca"=num_pres_atual,"academicoTurmaSituacao"=sit

where "academicoTurma"."academicoTurmaId"=acdTurmaId;
          END IF;

   END IF;
   RETURN 1;
END;
$$;

alter function frequenciaaula(integer, integer, integer, date, date, char, integer, real) owner to postgres;

