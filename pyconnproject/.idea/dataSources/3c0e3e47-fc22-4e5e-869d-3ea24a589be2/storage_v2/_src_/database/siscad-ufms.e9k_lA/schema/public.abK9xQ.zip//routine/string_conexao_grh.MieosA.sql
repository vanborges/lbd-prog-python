create function string_conexao_grh() returns text
    language plpgsql
as
$$
    -- devolve uma string de conexao com o banco do grh para 
	-- realizar a imortacao de dados via dblink.
DECLARE
	con_host  varchar ; -- maquina/servidor do banco
	con_port varchar; -- porta 
	con_db varchar; -- nome do banco
	con_user varchar; -- nome do usuario
	con_senha varchar ; -- senha do usuario
	
BEGIN
/*  
	DATA: 		31/08/2010
	AUTOR:		BRENO ROOSEVELT BARROS DE JESUS - 1636601	
	
	DESCRICAO:	1. Funcao usada para montar uma string de conexao com o banco de
			dados do RH. Essa string é usada nas visoes com prefixo "vdb_"
			no schema "grh". Lembre-se que essas visoes são usadas na function
			grh.importar_dados(). 

			2. Essa string é usada nas conexoes via "dblink" postgres-postgres
			
	MOTIVO:		A string precisava ser montada em varias visoes. 
	--------------------------------------------------------------------------------

	ANOTAÇÕES DE ALTERAÇÕES:
	========================
	
		DATA: 		__________
		AUTOR:		__________
		ALTERAÇÃO:	__________
		MOTIVO:		__________


		DATA: 		__________
		AUTOR:		__________
		ALTERAÇÃO:	__________
		MOTIVO:		__________

	--------------------------------------------------------------------------------
	 */	
	 
	con_host:= 'sgp.grh.ufms.br';
	con_port:= '5432';
	con_db= 'SistemaGRH';
	con_user:= 'bd_ufms_importacao';
	con_senha:= 'dus5e0@';

	RETURN ' dbname=' || con_db || ' port='||con_port||' user='||con_user ||' host='|| con_host ||' password='||con_senha ;
	
	
END;
$$;

comment on function string_conexao_grh() is 'A DOCUMENTACAO ESTA NO CORPO DA FUNCAO';

alter function string_conexao_grh() owner to postgres;

