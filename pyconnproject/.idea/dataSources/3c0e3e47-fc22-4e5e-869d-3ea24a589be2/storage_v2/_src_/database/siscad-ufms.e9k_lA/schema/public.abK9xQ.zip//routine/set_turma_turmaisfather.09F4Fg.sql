create function set_turma_turmaisfather() returns trigger
    language plpgsql
as
$$
DECLARE newTurmaPai INTEGER;
DECLARE oldTurmaPai INTEGER;
BEGIN
  	--
    -- Se for update. 
    --
    IF (TG_OP = 'UPDATE') THEN
        -- para evitar a chamada recursiva da trigger
    	-- desconsidere toda chamada onde o id da turma e 0.
    	IF NEW."turmaId" = 0 THEN
        	NEW."turmaId" := OLD."turmaId";
            return NEW;
        END IF;
        
        -- equivalente a: newTurmaPai := nullvalue(NEW."turmaPai") ? 0 : NEW."tu..."
      	SELECT (CASE WHEN NEW."turmaPai" IS NULL THEN 0 ELSE NEW."turmaPai" END) 
      	INTO newTurmaPai;
  
      	-- equivalente a: oldTurmaPai := nullvalue(OLD."turmaPai") ? 0 : OLD."tu..."
      	SELECT (CASE WHEN OLD."turmaPai" IS NULL THEN 0 ELSE OLD."turmaPai" END) 
      	INTO oldTurmaPai;
      
      	-- Se a turmaPai (old) <> turmaPai(new) atualizar turma[turmaPai].	         
    	IF  (oldTurmaPai != newTurmaPai ) THEN        	
            -- se o valor oldTurmaPai <> null atualiza o campo isFather 
            -- da turma[oldTurmaPai].
        	IF oldTurmaPai > 0 THEN -- atualiza a turma pai antiga.
                                    -- turmaId = 0 impede a chamada recursiva.
									
                UPDATE turma set "turmaId" = 0, "turmaIsFather" =
				(SELECT CASE WHEN count(*) > 1 THEN true ELSE false  END
				 FROM turma AS f       
				 WHERE f."turmaPai" = oldTurmaPai)
				 WHERE turma."turmaId" = oldTurmaPai;
            END IF;
            
            -- se o valor newTurmaPai <> null atualiza o campo isFather 
            -- da turma[newTurmaPai].
        	IF newTurmaPai > 0 THEN   -- turmaId = 0 impede a chamada recursiva.         	
            	
            	UPDATE turma set "turmaId" = 0, "turmaIsFather" = true				
				WHERE turma."turmaId" = newTurmaPai;
            END IF;          
            
    	END IF;   
        return NEW;
        
	ELSEIF (TG_OP = 'INSERT') THEN
		
    	-- Se a turmaPai <> null atualizar turma[turmaPai].	 
    	IF NEW."turmaPai"  IS NOT NULL THEN
        	
        	UPDATE turma set "turmaId" = 0, "turmaIsFather" = true				
			WHERE turma."turmaId" = NEW."turmaPai";
            
        END IF;    
        
    RETURN NEW;

	--
    -- Se for delete.
    --    
    ELSIF (TG_OP = 'DELETE') THEN
    	
    	-- Se a turmaPai <> null atualizar turma[turmaPai].	 
    	IF OLD."turmaPai" IS NOT NULL THEN
        	
        	UPDATE turma set "turmaId" = 0, "turmaIsFather" =            
			 (SELECT CASE WHEN count(*) > 1 THEN true ELSE false  END
			  FROM turma AS f       
			  WHERE f."turmaPai" = OLD."turmaPai")
			WHERE turma."turmaId" = OLD."turmaPai";

    	END IF;
    RETURN OLD;
    END IF;
END;
$$;

alter function set_turma_turmaisfather() owner to postgres;

