create view "ViewEmailEnviado"("ViewEmailEnviadoId", "ViewEmailEnviadoUsrId", "ViewEmailEnviadoNomeDestinatario",
                               "ViewEmailEnviadoEmailDestinatario", "ViewEmailEnviadoNomeEmailDestinatario",
                               "ViewEmailEnviadoAssunto", "ViewEmailEnviadoConteudo", "ViewEmailEnviadoData",
                               "ViewEmailEnviadoLido") as
SELECT e."emailEnviadoId"                                      AS "ViewEmailEnviadoId",
       e."usrId"                                               AS "ViewEmailEnviadoUsrId",
       r."emailRecebidoNome"                                   AS "ViewEmailEnviadoNomeDestinatario",
       r."emailRecebidoEmail"                                  AS "ViewEmailEnviadoEmailDestinatario",
       (((('"'::text || (r."emailRecebidoNome")::text) || '" &lt;'::text) || (r."emailRecebidoEmail")::text) ||
        '&gt;'::text)                                          AS "ViewEmailEnviadoNomeEmailDestinatario",
       e."emailEnviadoAssunto"                                 AS "ViewEmailEnviadoAssunto",
       e."emailEnviadoConteudo"                                AS "ViewEmailEnviadoConteudo",
       to_char(e."emailEnviadoCreateDate", 'dd/mm/yyyy'::text) AS "ViewEmailEnviadoData",
       true                                                    AS "ViewEmailEnviadoLido"
FROM ("emailEnviado" e
         JOIN "emailRecebido" r ON ((e."emailEnviadoId" = r."emailEnviadoId")))
WHERE (e."emailEnviadoExcluido" IS FALSE)
ORDER BY e."emailEnviadoId", e."emailEnviadoCreateDate" DESC;

alter table "ViewEmailEnviado"
    owner to postgres;

