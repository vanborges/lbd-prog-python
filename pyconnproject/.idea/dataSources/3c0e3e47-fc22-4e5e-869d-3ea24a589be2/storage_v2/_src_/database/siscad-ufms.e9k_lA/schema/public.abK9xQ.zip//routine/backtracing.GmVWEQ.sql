create function backtracing() returns trigger
    language plpgsql
as
$$
BEGIN
 if new."academicoTurmaFaltas" < 0 THEN
    insert into backtracing values (now(), new."academicoTurmaId" || 'falta antiga : ' || old."academicoTurmaFaltas" || 'falta nova : ' || new."academicoTurmaFaltas" );
  end if;
  return new;
END;
$$;

alter function backtracing() owner to postgres;

