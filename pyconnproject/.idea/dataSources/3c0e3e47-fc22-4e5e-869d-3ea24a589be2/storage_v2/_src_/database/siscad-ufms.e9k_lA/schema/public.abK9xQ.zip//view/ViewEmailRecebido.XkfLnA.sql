create view "ViewEmailRecebido"("ViewEmailRecebidoId", "ViewEmailRecebidoUsrId", "ViewEmailRecebidoAssunto",
                                "ViewEmailRecebidoConteudo", "ViewEmailRecebidoNomeRemetente", "ViewEmailRecebidoData",
                                "ViewEmailRecebidoLido", "ViewEmailRecebidoNotificado") as
SELECT r."emailRecebidoId"                                      AS "ViewEmailRecebidoId",
       r."usrId"                                                AS "ViewEmailRecebidoUsrId",
       e."emailEnviadoAssunto"                                  AS "ViewEmailRecebidoAssunto",
       e."emailEnviadoConteudo"                                 AS "ViewEmailRecebidoConteudo",
       e."emailEnviadoNome"                                     AS "ViewEmailRecebidoNomeRemetente",
       to_char(r."emailRecebidoCreateDate", 'dd/mm/yyyy'::text) AS "ViewEmailRecebidoData",
       r."emailRecebidoLido"                                    AS "ViewEmailRecebidoLido",
       r."emailRecebidoNotificado"                              AS "ViewEmailRecebidoNotificado"
FROM ("emailEnviado" e
         JOIN "emailRecebido" r ON ((e."emailEnviadoId" = r."emailEnviadoId")))
WHERE (r."emailRecebidoExcluido" IS FALSE)
ORDER BY r."emailRecebidoCreateDate" DESC;

alter table "ViewEmailRecebido"
    owner to postgres;

