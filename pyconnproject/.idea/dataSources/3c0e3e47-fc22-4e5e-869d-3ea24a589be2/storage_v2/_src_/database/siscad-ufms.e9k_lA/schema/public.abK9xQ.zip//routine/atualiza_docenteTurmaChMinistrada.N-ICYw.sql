create function "atualiza_docenteTurmaChMinistrada"() returns trigger
    language plpgsql
as
$$
DECLARE
  ChMinistrada real;
BEGIN
	IF (TG_OP = 'DELETE') THEN
	    SELECT sum(h."horarioCargaHorariaDia"*h."horarioSemanas") as "ChMinistrada"
	    FROM "horario" h
	    WHERE h."turmaId" = OLD."turmaId"
	    AND h."docenteId" = OLD."docenteId" into ChMinistrada;
    
    	UPDATE "docenteTurma" SET "docenteTurmaChMinistrada" = ChMinistrada
	    where "turmaId" = OLD."turmaId"
	    and "docenteId" = OLD."docenteId";
		RETURN OLD;
	ELSIF ((TG_OP = 'UPDATE') OR (TG_OP = 'INSERT')) THEN
	    SELECT sum(h."horarioCargaHorariaDia"*h."horarioSemanas") as "ChMinistrada"
	    FROM "horario" h
	    WHERE h."turmaId" = NEW."turmaId"
	    AND h."docenteId" = NEW."docenteId" into ChMinistrada;
    
    	UPDATE "docenteTurma" SET "docenteTurmaChMinistrada" = ChMinistrada
	    where "turmaId" = NEW."turmaId"
	    and "docenteId" = NEW."docenteId";
    	RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

alter function "atualiza_docenteTurmaChMinistrada"() owner to postgres;

