create function last_agg(anyelement, anyelement) returns anyelement
    immutable
    strict
    language sql
as
$$
SELECT $2;
$$;

alter function last_agg(anyelement, anyelement) owner to postgres;

