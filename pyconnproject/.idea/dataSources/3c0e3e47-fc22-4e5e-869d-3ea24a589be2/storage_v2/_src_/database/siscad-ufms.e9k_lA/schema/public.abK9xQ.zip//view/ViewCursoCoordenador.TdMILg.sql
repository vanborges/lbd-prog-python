create view "ViewCursoCoordenador"("ViewCursoCoordenadorCursoNome", "ViewCursoCoordenadorCursoCodigo",
                                   "ViewCursoCoordenadorDocenteId", "ViewCursoCoordenadorId",
                                   "ViewCursoCoordenadorCursoId") as
SELECT cu."cursoNome"   AS "ViewCursoCoordenadorCursoNome",
       cu."cursoCodigo" AS "ViewCursoCoordenadorCursoCodigo",
       co."docenteId"   AS "ViewCursoCoordenadorDocenteId",
       cu."cursoCodigo" AS "ViewCursoCoordenadorId",
       cu."cursoId"     AS "ViewCursoCoordenadorCursoId"
FROM (curso cu
         JOIN coordenador co ON ((cu."cursoId" = co."cursoId")));

alter table "ViewCursoCoordenador"
    owner to postgres;

