create function "qualEhASenha"(login character varying) returns "2words"
    language plpgsql
as
$$
DECLARE
  --variable_name datatype;
BEGIN
  
--    RETURN QUERY
    select u."usrLogin" as "senha", 'a senha é o RGA' as "o que"
    from usr u
    where u."usrLogin" = login
    and u."usrPassword" = sha1(u."usrLogin")
    union
    select a."academicoCpf" as "senha", 'a senha é o cpf' as "o que"
    from usr u
    join academico a on u."usrLogin" = a."academicoRga" and u."foreignId" = a."academicoId"
    where u."usrLogin" = login
    and u."usrPassword" = sha1(a."academicoCpf")
    UNION
    SELECT '???' as "senha", 'não sei qual é a senha' as "o que"
    from usr u
    join academico a on u."usrLogin" = a."academicoRga" and u."foreignId" = a."academicoId"
    where u."usrLogin" = login
    and u."usrPassword" != sha1(a."academicoCpf")
    and u."usrPassword" != sha1(u."usrLogin");

END;
$$;

alter function "qualEhASenha"(varchar) owner to postgres;

