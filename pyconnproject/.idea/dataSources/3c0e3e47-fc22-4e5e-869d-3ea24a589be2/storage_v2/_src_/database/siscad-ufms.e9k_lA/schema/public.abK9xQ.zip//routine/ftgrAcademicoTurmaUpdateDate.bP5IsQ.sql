create function "ftgrAcademicoTurmaUpdateDate"() returns trigger
    language plpgsql
as
$$
BEGIN
  NEW."academicoTurmaUpdateDate" := now();
  RETURN NEW;
END;
$$;

alter function "ftgrAcademicoTurmaUpdateDate"() owner to postgres;

