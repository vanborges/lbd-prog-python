create function alter_owner(newoner character varying) returns integer
    language plpgsql
as
$$
/* New function body */
DECLARE
 new_owner ALIAS FOR $1;
 pointer1 RECORD;
 string VARCHAR(255);
 sql text;

BEGIN
     FOR pointer1 IN
         --percorrer todas as tabelas
         select relname
         from pg_class
         where relkind in ('r','i','S','v') and relnamespace = 2200
     LOOP
         string := pointer1.relname;
         sql = 'alter table "' || string || '" owner to ' || new_owner;
         --%RAISE NOTICE '(%)',sql;
         EXECUTE(sql);
     END LOOP;
     RETURN 1;
END;
$$;

alter function alter_owner(varchar) owner to postgres;

