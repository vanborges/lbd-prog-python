create view "ViewSIENDocente"(id, "docenteMatricula", "docenteDigitoVerificador", "docenteUfms", nome, "docenteVinculo",
                              "docenteSituacaoOcor", "docenteSituacao", "docenteGrupoSituacao", "docenteTipoSituacao",
                              "docenteSexo", "docenteOcorTitulacao", "docenteClasse", "docenteNivel", "docenteArea",
                              "docenteTitulacao", "docenteRegimeTrabalho", "docenteOcorFuncao", "docenteOrigemLotacao",
                              "docenteFuncaoLotacao", "docenteAtividade", "docenteTipoFuncao", "docenteNivelFuncao",
                              "docenteDataAdimissao", "docenteAnoDtBase", "docenteMesDtBase", "docenteAno",
                              "docenteDepIngresso", "docenteTutor", "docenteOcorDepartamento", "docenteDepartamento",
                              "docenteObs", "docenteParteNome", "docenteCreateDate", "vinculoId", "docenteCpf",
                              "titulacaoId", centro_id) as
SELECT doc."docenteId"   AS id,
       doc."docenteMatricula",
       doc."docenteDigitoVerificador",
       doc."docenteUfms",
       doc."docenteNome" AS nome,
       doc."docenteVinculo",
       doc."docenteSituacaoOcor",
       doc.sit_real_cod  AS "docenteSituacao",
       doc."docenteGrupoSituacao",
       doc."docenteTipoSituacao",
       doc."docenteSexo",
       doc."docenteOcorTitulacao",
       doc."docenteClasse",
       doc."docenteNivel",
       doc."docenteArea",
       doc."docenteTitulacao",
       doc."docenteRegimeTrabalho",
       doc."docenteOcorFuncao",
       doc."docenteOrigemLotacao",
       doc."docenteFuncaoLotacao",
       doc."docenteAtividade",
       doc."docenteTipoFuncao",
       doc."docenteNivelFuncao",
       doc."docenteDataAdimissao",
       doc."docenteAnoDtBase",
       doc."docenteMesDtBase",
       doc."docenteAno",
       doc."docenteDepIngresso",
       doc."docenteTutor",
       doc."docenteOcorDepartamento",
       doc."docenteDepartamento",
       doc."docenteObs",
       doc."docenteParteNome",
       doc."docenteCreateDate",
       doc."vinculoId",
       doc."docenteCpf",
       doc."titulacaoId",
       dep."centroId"    AS centro_id
FROM (docente doc
         LEFT JOIN departamento dep ON ((doc."docenteDepartamento" = dep."departamentoId")))
WHERE ((doc."docenteSituacao" <> ALL (ARRAY ['02'::bpchar, '05'::bpchar])) AND
       ((doc."docenteMatricula")::text <> '00000000000'::text))
ORDER BY doc."docenteNome";

alter table "ViewSIENDocente"
    owner to postgres;

