create view "ViewSIENGrade"(id, "estruturaId", "estruturaAnoIni", "estruturaSemIni", "estruturaAnoFim",
                            "estruturaSemFim", "estruturaSerie", "estruturaNotaObr", "estruturaFrequenciaObr",
                            "estruturaTipoDisciplina", "estruturaTipoEquiv", "estruturaDocumentoIni",
                            "estruturaDocumentoFim", "estruturaSituacao", "estruturaCargaPratica",
                            "estruturaCargaTeorica", "estruturaOptativa", "estruturaCreateDate",
                            "estruturaCargaHorariaLimitada", "estruturaUpdateDate", "disciplinaId", "disciplinaCodigo",
                            "departamentoId", "disciplinaNome", "disciplinaCarga", "disciplinaSituacao",
                            "disciplinaCfe", "disciplinaCreateDate", curso_codigo) as
SELECT g."gradeId"     AS id,
       e."estruturaId",
       e."estruturaAnoIni",
       e."estruturaSemIni",
       e."estruturaAnoFim",
       e."estruturaSemFim",
       CASE
           WHEN (e."estruturaSerie" = 0) THEN 99
           ELSE (e."estruturaSerie")::integer
           END         AS "estruturaSerie",
       e."estruturaNotaObr",
       e."estruturaFrequenciaObr",
       e."estruturaTipoDisciplina",
       e."estruturaTipoEquiv",
       e."estruturaDocumentoIni",
       e."estruturaDocumentoFim",
       e."estruturaSituacao",
       e."estruturaCargaPratica",
       e."estruturaCargaTeorica",
       e."estruturaOptativa",
       e."estruturaCreateDate",
       e."estruturaCargaHorariaLimitada",
       e."estruturaUpdateDate",
       d."disciplinaId",
       d."disciplinaCodigo",
       d."departamentoId",
       d."disciplinaNome",
       d."disciplinaCarga",
       d."disciplinaSituacao",
       d."disciplinaCfe",
       d."disciplinaCreateDate",
       c."cursoCodigo" AS curso_codigo
FROM (((grade g
    LEFT JOIN estrutura e ON ((e."estruturaId" = g."estruturaId")))
    LEFT JOIN curso c ON ((c."cursoId" = g."cursoId")))
         LEFT JOIN disciplina d ON ((d."disciplinaId" = g."disciplinaId")))
WHERE ((c."cursoCodigo", c."cursoSequencia") IN (SELECT curso."cursoCodigo",
                                                        max(curso."cursoSequencia") AS max
                                                 FROM curso
                                                 GROUP BY curso."cursoCodigo"))
ORDER BY CASE
             WHEN (e."estruturaSerie" = 0) THEN 99
             ELSE (e."estruturaSerie")::integer
             END;

alter table "ViewSIENGrade"
    owner to postgres;

