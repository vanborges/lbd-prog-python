create view vpessoa(cpf, nome_dependente, sexo) as
    SELECT funcionario.cpf,
           funcionario.pnome AS nome_dependente,
           funcionario.sexo
    FROM empresaschema.funcionario
    UNION
    SELECT dependente.fcpf AS cpf,
           dependente.nome_dependente,
           dependente.sexo
    FROM empresaschema.dependente;

alter table vpessoa
    owner to postgres;

